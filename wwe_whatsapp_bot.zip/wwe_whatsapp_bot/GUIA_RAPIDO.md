# 🚀 Guia Rápido - WWE RPG WhatsApp Bot

## ⚡ Configuração Express (15 minutos)

### 1️⃣ Preparar WhatsApp Business API

1. **Acesse**: [developers.facebook.com](https://developers.facebook.com)
2. **Crie um App** → Selecione "Business"
3. **Adicione WhatsApp** → Configure seu chip novo
4. **Anote as credenciais**:
   - Token de Acesso
   - Phone Number ID
   - Business Account ID

### 2️⃣ Instalar o Bot

```bash
# Extrair arquivos
tar -xzf wwe_whatsapp_bot_completo.tar.gz
cd wwe_whatsapp_bot

# Instalar Python e dependências
sudo apt install python3.11 python3.11-venv ffmpeg -y
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3️⃣ Configurar

```bash
# Editar configurações
nano .env
```

**Cole suas credenciais**:
```env
WHATSAPP_TOKEN=seu_token_aqui
VERIFY_TOKEN=meutoken123
PHONE_NUMBER_ID=seu_phone_id
WHATSAPP_BUSINESS_ACCOUNT_ID=seu_business_id
ADMIN_NUMBERS=+5511999999999
```

### 4️⃣ Executar

```bash
# Iniciar bot
python src/main.py
```

### 5️⃣ Configurar Webhook

No Meta Developers:
- **URL**: `https://seu-dominio.com/api/webhook`
- **Token**: `meutoken123` (mesmo do .env)
- **Eventos**: `messages`

## 🎯 Teste Rápido

Envie para o bot:
- `!help` - Ver comandos
- `!play john cena` - Testar áudio
- `!character Stone Cold` - Criar personagem

## 🆘 Problemas?

- **Bot não responde**: Verificar webhook
- **!play não funciona**: Instalar ffmpeg
- **Sem permissão**: Verificar ADMIN_NUMBERS

---

**✅ Pronto! Seu bot WWE está funcionando!**

Para configuração completa, veja: [MANUAL_INSTALACAO.md](MANUAL_INSTALACAO.md)

