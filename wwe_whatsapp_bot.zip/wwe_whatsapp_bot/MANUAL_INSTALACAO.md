# 🤖 Manual de Instalação - WWE RPG WhatsApp Bot

## 📋 Índice

1. [Visão Geral](#visão-geral)
2. [Pré-requisitos](#pré-requisitos)
3. [Configuração da API do WhatsApp Business](#configuração-da-api-do-whatsapp-business)
4. [Instalação do Bot](#instalação-do-bot)
5. [Configuração](#configuração)
6. [Execução](#execução)
7. [Comandos Disponíveis](#comandos-disponíveis)
8. [Solução de Problemas](#solução-de-problemas)
9. [Suporte](#suporte)

---

## 🎯 Visão Geral

O **WWE RPG WhatsApp Bot** é um bot completo e profissional desenvolvido especificamente para grupos de WhatsApp focados em RPG de WWE. Ele oferece funcionalidades avançadas de administração, sistema de RPG com personagens e batalhas, reprodução de músicas de entrada e muito mais.

### ✨ Principais Funcionalidades

- **🎵 Sistema de Áudio**: Comando `!play` para tocar qualquer música de entrada
- **👮 Administração Avançada**: Auto ban, mute, warn e sistema de permissões
- **🤼 RPG Completo**: Criação de personagens, batalhas, sistema de níveis
- **🏆 Sistema de Campeonatos**: Gerenciamento de títulos e rankings
- **🎲 Sistema de Dados**: Rolagem de dados para eventos aleatórios
- **📊 Estatísticas**: Tracking completo de atividades e performance

---

## 🔧 Pré-requisitos

Antes de começar, certifique-se de ter:

### Sistema Operacional
- **Linux** (Ubuntu 20.04+ recomendado)
- **Windows** (com WSL2) ou **macOS**

### Software Necessário
- **Python 3.11+**
- **pip** (gerenciador de pacotes Python)
- **git** (para clonagem do repositório)
- **ffmpeg** (para processamento de áudio)

### Conta WhatsApp Business
- Número de telefone dedicado (recomendado usar o chip novo que você comprou)
- Conta Meta Business (Facebook Business)
- Acesso à Meta Cloud API

---

## 📱 Configuração da API do WhatsApp Business

### Passo 1: Criar Conta Meta Business

1. Acesse [business.facebook.com](https://business.facebook.com)
2. Clique em "Criar Conta" se não tiver uma
3. Preencha as informações da sua empresa/projeto
4. Verifique sua conta conforme solicitado

### Passo 2: Configurar WhatsApp Business API

1. No Meta Business Manager, vá para "Todas as ferramentas"
2. Selecione "WhatsApp Manager"
3. Clique em "Começar" e siga as instruções
4. Adicione seu número de telefone (o chip novo)
5. Verifique o número via SMS ou chamada

### Passo 3: Obter Credenciais da API

1. Acesse [developers.facebook.com](https://developers.facebook.com)
2. Vá para "Meus Apps" e crie um novo app
3. Selecione "Business" como tipo de app
4. Adicione o produto "WhatsApp Business API"
5. Configure as permissões necessárias

### Passo 4: Coletar Informações Necessárias

Você precisará das seguintes informações:

- **Token de Acesso** (`WHATSAPP_TOKEN`)
- **ID do Número de Telefone** (`PHONE_NUMBER_ID`)
- **ID da Conta Business** (`WHATSAPP_BUSINESS_ACCOUNT_ID`)
- **Token de Verificação** (`VERIFY_TOKEN`) - você pode criar qualquer string

> **💡 Dica**: Anote essas informações em um local seguro, você precisará delas na configuração.

---

## 💻 Instalação do Bot

### Passo 1: Preparar o Ambiente

```bash
# Atualizar sistema (Ubuntu/Debian)
sudo apt update && sudo apt upgrade -y

# Instalar dependências do sistema
sudo apt install python3.11 python3.11-venv python3-pip git ffmpeg -y

# Verificar instalação do Python
python3.11 --version
```

### Passo 2: Clonar o Projeto

```bash
# Navegar para diretório desejado
cd /home/$(whoami)

# Clonar o repositório (substitua pela localização real)
# Como este é um projeto personalizado, você receberá os arquivos
mkdir wwe_whatsapp_bot
cd wwe_whatsapp_bot

# Extrair arquivos do projeto aqui
```

### Passo 3: Criar Ambiente Virtual

```bash
# Criar ambiente virtual
python3.11 -m venv venv

# Ativar ambiente virtual
source venv/bin/activate

# Verificar ativação (deve mostrar o caminho do venv)
which python
```

### Passo 4: Instalar Dependências

```bash
# Instalar dependências do projeto
pip install -r requirements.txt

# Verificar instalação
pip list
```

---

## ⚙️ Configuração

### Passo 1: Configurar Variáveis de Ambiente

1. **Copie o arquivo de exemplo**:
```bash
cp .env.example .env
```

2. **Edite o arquivo `.env`**:
```bash
nano .env
```

3. **Preencha as configurações**:
```env
# Configurações do WhatsApp Bot
WHATSAPP_TOKEN=seu_token_aqui
VERIFY_TOKEN=seu_token_de_verificacao
PHONE_NUMBER_ID=seu_phone_number_id
WHATSAPP_BUSINESS_ACCOUNT_ID=seu_business_account_id

# Configurações do Bot
BOT_NAME=WWE RPG Bot
BOT_VERSION=1.0.0

# Configurações de Administração (seus números com código do país)
ADMIN_NUMBERS=+5511999999999,+5511888888888

# Configurações de Áudio
AUDIO_DOWNLOAD_PATH=./downloads/audio
MAX_AUDIO_DURATION=300

# Configurações do Banco de Dados
DATABASE_URL=sqlite:///src/database/app.db

# Configurações de Debug
DEBUG=True
LOG_LEVEL=INFO
```

### Passo 2: Configurar Administradores

No arquivo `.env`, na linha `ADMIN_NUMBERS`, adicione os números dos administradores:

```env
ADMIN_NUMBERS=+5511999999999,+5511888888888,+5511777777777
```

> **⚠️ Importante**: Use o formato internacional com código do país (+55 para Brasil)

### Passo 3: Criar Diretórios Necessários

```bash
# Criar diretórios de download e logs
mkdir -p downloads/audio
mkdir -p logs
```

---

## 🚀 Execução

### Passo 1: Inicializar Banco de Dados

```bash
# Ativar ambiente virtual (se não estiver ativo)
source venv/bin/activate

# Executar inicialização
python src/main.py
```

Na primeira execução, o bot criará automaticamente:
- Banco de dados SQLite
- Tabelas necessárias
- Personagens WWE pré-cadastrados

### Passo 2: Configurar Webhook

1. **Execute o bot**:
```bash
python src/main.py
```

2. **Configure o webhook no Meta Developers**:
   - URL do webhook: `https://seu-dominio.com/api/webhook`
   - Token de verificação: o mesmo que você definiu em `VERIFY_TOKEN`
   - Eventos para assinar: `messages`, `message_deliveries`, `message_reads`

### Passo 3: Testar o Bot

1. **Envie uma mensagem de teste** para o número do bot
2. **Use o comando** `!help` para ver se está funcionando
3. **Verifique os logs** para identificar possíveis problemas

---

## 📖 Comandos Disponíveis

### 🎵 Comandos de Áudio

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `!play <música>` | Toca música de entrada | `!play john cena theme` |
| `!stop` | Para a música atual | `!stop` |

### 👮 Comandos Administrativos

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `!ban <usuário>` | Banir usuário (admin) | `!ban @usuario` |
| `!unban <usuário>` | Desbanir usuário (admin) | `!unban @usuario` |
| `!warn <usuário> <motivo>` | Avisar usuário (admin) | `!warn @usuario spam` |
| `!mute <usuário>` | Mutar usuário (admin) | `!mute @usuario` |
| `!unmute <usuário>` | Desmutar usuário (admin) | `!unmute @usuario` |

### 🤼 Comandos de RPG

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `!character <nome>` | Criar/ver personagem | `!character Stone Cold` |
| `!stats` | Ver suas estatísticas | `!stats` |
| `!match <tipo>` | Iniciar luta | `!match singles` |
| `!roll <dado>` | Rolar dados | `!roll d20` |
| `!entrance` | Fazer entrada épica | `!entrance` |
| `!finisher <oponente>` | Usar finalizadora | `!finisher @oponente` |

### 🏆 Comandos de Campeonato

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `!championship` | Ver campeonatos | `!championship` |
| `!roster` | Ver roster completo | `!roster` |
| `!leaderboard` | Ver ranking | `!leaderboard` |

### ℹ️ Comandos Gerais

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `!help` | Lista de comandos | `!help` |
| `!admin` | Comandos admin (admin) | `!admin` |

---

## 🔧 Solução de Problemas

### Problema: Bot não responde

**Possíveis causas**:
- Webhook não configurado corretamente
- Token de acesso inválido
- Número não verificado

**Soluções**:
1. Verifique as configurações no arquivo `.env`
2. Confirme se o webhook está ativo no Meta Developers
3. Teste a conectividade com a API

### Problema: Comando `!play` não funciona

**Possíveis causas**:
- ffmpeg não instalado
- Problemas de conectividade
- Formato de áudio não suportado

**Soluções**:
```bash
# Instalar ffmpeg
sudo apt install ffmpeg

# Verificar instalação
ffmpeg -version

# Testar download manual
yt-dlp "ytsearch:john cena theme"
```

### Problema: Erro de permissão

**Possíveis causas**:
- Usuário não é administrador
- Configuração incorreta de ADMIN_NUMBERS

**Soluções**:
1. Verifique se seu número está em `ADMIN_NUMBERS`
2. Use formato internacional (+55...)
3. Reinicie o bot após alterar configurações

### Problema: Banco de dados corrompido

**Soluções**:
```bash
# Backup do banco atual
cp src/database/app.db src/database/app.db.backup

# Remover banco corrompido
rm src/database/app.db

# Reiniciar bot (criará novo banco)
python src/main.py
```

---

## 📞 Suporte

### Logs e Debugging

Para ativar logs detalhados:

```bash
# Definir nível de log
export LOG_LEVEL=DEBUG

# Executar com logs verbosos
python src/main.py
```

### Arquivos de Log

Os logs são salvos em:
- `logs/bot.log` - Log principal do bot
- `logs/admin.log` - Log de ações administrativas
- `logs/rpg.log` - Log de eventos de RPG

### Comandos de Diagnóstico

```bash
# Verificar status do bot
curl http://localhost:5000/api/webhook/status

# Verificar estatísticas (admin)
curl http://localhost:5000/api/webhook/admin/stats
```

### Contato para Suporte

Se você encontrar problemas não cobertos neste manual:

1. **Verifique os logs** primeiro
2. **Consulte a documentação** da Meta WhatsApp API
3. **Teste em ambiente isolado** antes de usar em produção

---

## 🎉 Conclusão

Parabéns! Você agora tem um bot de WhatsApp completo e profissional para seu RPG de WWE. O bot está equipado com:

- ✅ Sistema de administração avançado
- ✅ Funcionalidades de RPG completas
- ✅ Reprodução de áudio
- ✅ Sistema de campeonatos
- ✅ Moderação automática
- ✅ Interface intuitiva

**Lembre-se**:
- Mantenha suas credenciais seguras
- Faça backups regulares do banco de dados
- Monitore os logs para identificar problemas
- Use o bot de forma responsável

**Desenvolvido por Manus AI** 🚀

---

*Este manual foi criado especificamente para seu projeto. Para atualizações e melhorias, consulte a documentação mais recente.*

