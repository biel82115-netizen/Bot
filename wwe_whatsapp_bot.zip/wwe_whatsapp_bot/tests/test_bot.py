import unittest
import json
from unittest.mock import Mock, patch
import sys
import os

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src.services.rpg_service import RPGService
from src.services.admin_service import AdminService
from src.services.audio_service import AudioService
from src.services.wwe_data_service import WWEDataService

class TestRPGService(unittest.TestCase):
    """Testes para o serviço de RPG"""
    
    def setUp(self):
        self.rpg_service = RPGService()
    
    def test_roll_dice_valid(self):
        """Testar rolagem de dados válida"""
        result = self.rpg_service.roll_dice('d20')
        
        self.assertTrue(result['success'])
        self.assertEqual(result['num_dice'], 1)
        self.assertEqual(result['sides'], 20)
        self.assertEqual(len(result['rolls']), 1)
        self.assertTrue(1 <= result['rolls'][0] <= 20)
        self.assertEqual(result['total'], result['rolls'][0])
    
    def test_roll_dice_multiple(self):
        """Testar rolagem de múltiplos dados"""
        result = self.rpg_service.roll_dice('3d6')
        
        self.assertTrue(result['success'])
        self.assertEqual(result['num_dice'], 3)
        self.assertEqual(result['sides'], 6)
        self.assertEqual(len(result['rolls']), 3)
        for roll in result['rolls']:
            self.assertTrue(1 <= roll <= 6)
        self.assertEqual(result['total'], sum(result['rolls']))
    
    def test_roll_dice_invalid(self):
        """Testar rolagem de dados inválida"""
        result = self.rpg_service.roll_dice('invalid')
        self.assertFalse(result['success'])
        
        result = self.rpg_service.roll_dice('11d6')  # Muitos dados
        self.assertFalse(result['success'])
        
        result = self.rpg_service.roll_dice('d101')  # Muitos lados
        self.assertFalse(result['success'])
    
    def test_match_types(self):
        """Testar tipos de luta disponíveis"""
        self.assertIn('singles', self.rpg_service.match_types)
        self.assertIn('triple_threat', self.rpg_service.match_types)
        self.assertIn('battle_royal', self.rpg_service.match_types)
        
        singles = self.rpg_service.match_types['singles']
        self.assertEqual(singles['participants'], 2)
        self.assertIn('pinfall', singles['win_conditions'])
    
    def test_basic_actions(self):
        """Testar ações básicas disponíveis"""
        self.assertTrue(len(self.rpg_service.basic_actions) > 0)
        
        for action in self.rpg_service.basic_actions:
            self.assertIsInstance(action.name, str)
            self.assertIsInstance(action.damage_range, tuple)
            self.assertEqual(len(action.damage_range), 2)
            self.assertTrue(0 <= action.accuracy <= 100)
            self.assertTrue(action.stamina_cost >= 0)

class TestAdminService(unittest.TestCase):
    """Testes para o serviço de administração"""
    
    def setUp(self):
        self.admin_service = AdminService(['admin1', 'admin2'])
    
    def test_is_admin(self):
        """Testar verificação de administrador"""
        self.assertTrue(self.admin_service.is_admin('admin1'))
        self.assertTrue(self.admin_service.is_admin('admin2'))
        self.assertFalse(self.admin_service.is_admin('user1'))
    
    def test_has_permission(self):
        """Testar sistema de permissões"""
        # Admins têm permissão por padrão
        self.assertTrue(self.admin_service.has_permission('admin1', 'ban'))
        self.assertTrue(self.admin_service.has_permission('admin1', 'mute'))
        
        # Usuários normais não têm permissão
        self.assertFalse(self.admin_service.has_permission('user1', 'ban'))
    
    def test_ban_user(self):
        """Testar banimento de usuário"""
        result = self.admin_service.ban_user('user1', 'admin1', 'Test ban')
        
        self.assertTrue(result['success'])
        self.assertEqual(result['ban_type'], 'permanent')
        self.assertTrue(self.admin_service.is_user_banned('user1'))
    
    def test_ban_user_temporary(self):
        """Testar banimento temporário"""
        result = self.admin_service.ban_user('user1', 'admin1', 'Test ban', duration=60)
        
        self.assertTrue(result['success'])
        self.assertEqual(result['ban_type'], 'temporary')
        self.assertEqual(result['duration_minutes'], 60)
        self.assertTrue(self.admin_service.is_user_banned('user1'))
    
    def test_unban_user(self):
        """Testar desbanimento"""
        # Banir primeiro
        self.admin_service.ban_user('user1', 'admin1', 'Test ban')
        self.assertTrue(self.admin_service.is_user_banned('user1'))
        
        # Desbanir
        result = self.admin_service.unban_user('user1', 'admin1')
        self.assertTrue(result['success'])
        self.assertFalse(self.admin_service.is_user_banned('user1'))
    
    def test_mute_user(self):
        """Testar mute de usuário"""
        result = self.admin_service.mute_user('user1', 'admin1', 'Test mute')
        
        self.assertTrue(result['success'])
        self.assertEqual(result['mute_type'], 'permanent')
        self.assertTrue(self.admin_service.is_user_muted('user1'))
    
    def test_add_warning(self):
        """Testar sistema de avisos"""
        result = self.admin_service.add_warning('user1', 'Test warning', 'admin1')
        
        self.assertTrue(result['success'])
        self.assertEqual(result['warning_count'], 1)
        self.assertEqual(result['max_warnings'], 3)
    
    def test_auto_moderation(self):
        """Testar moderação automática"""
        result = self.admin_service.check_auto_moderation('user1', 'This message contains spam')
        
        self.assertIn('violations', result)
        self.assertIn('actions_taken', result)
        self.assertIn('should_block_message', result)
        
        # Deve detectar palavra proibida
        self.assertTrue(len(result['violations']) > 0)

class TestAudioService(unittest.TestCase):
    """Testes para o serviço de áudio"""
    
    def setUp(self):
        self.audio_service = AudioService(download_path='/tmp/test_audio')
    
    def test_initialization(self):
        """Testar inicialização do serviço"""
        self.assertEqual(self.audio_service.download_path, '/tmp/test_audio')
        self.assertEqual(self.audio_service.max_duration, 300)
        self.assertIsInstance(self.audio_service.ydl_opts, dict)
    
    @patch('os.path.exists')
    @patch('os.listdir')
    def test_find_downloaded_file(self, mock_listdir, mock_exists):
        """Testar busca de arquivo baixado"""
        mock_exists.return_value = True
        mock_listdir.return_value = ['John Cena Theme Song.mp3', 'other_file.txt']
        
        result = self.audio_service._find_downloaded_file('John Cena Theme Song')
        self.assertIsNotNone(result)
        self.assertIn('John Cena Theme Song.mp3', result)
    
    def test_get_audio_info_invalid_file(self):
        """Testar obtenção de info de arquivo inválido"""
        result = self.audio_service.get_audio_info('/invalid/path/file.mp3')
        self.assertIsNone(result)

class TestWWEDataService(unittest.TestCase):
    """Testes para o serviço de dados WWE"""
    
    def setUp(self):
        self.wwe_service = WWEDataService()
    
    def test_get_popular_characters(self):
        """Testar obtenção de personagens populares"""
        characters = self.wwe_service.get_popular_wwe_characters()
        
        self.assertIsInstance(characters, list)
        self.assertTrue(len(characters) > 0)
        
        # Verificar estrutura do primeiro personagem
        if characters:
            char = characters[0]
            self.assertIn('name', char)
            self.assertIn('real_name', char)
            self.assertIn('entrance_music', char)
            self.assertIn('finisher_moves', char)
    
    def test_calculate_character_stats(self):
        """Testar cálculo de estatísticas"""
        char_data = {'name': 'John Cena'}
        stats = self.wwe_service.calculate_character_stats(char_data)
        
        self.assertIsInstance(stats, dict)
        self.assertIn('strength', stats)
        self.assertIn('speed', stats)
        self.assertIn('charisma', stats)
        self.assertIn('technique', stats)
        self.assertIn('stamina', stats)
        
        # Verificar que todos os stats estão entre 0 e 100
        for stat_value in stats.values():
            self.assertTrue(0 <= stat_value <= 100)
    
    def test_get_entrance_music_suggestions(self):
        """Testar sugestões de música de entrada"""
        suggestions = self.wwe_service.get_entrance_music_suggestions('john cena')
        
        self.assertIsInstance(suggestions, list)
        # Deve encontrar pelo menos uma sugestão para John Cena
        self.assertTrue(any('John Cena' in suggestion for suggestion in suggestions))
    
    def test_get_match_types(self):
        """Testar tipos de luta"""
        match_types = self.wwe_service.get_match_types()
        
        self.assertIsInstance(match_types, list)
        self.assertTrue(len(match_types) > 0)
        
        # Verificar estrutura
        if match_types:
            match_type = match_types[0]
            self.assertIn('type', match_type)
            self.assertIn('name', match_type)
            self.assertIn('description', match_type)
            self.assertIn('participants', match_type)

class TestIntegration(unittest.TestCase):
    """Testes de integração"""
    
    def test_services_initialization(self):
        """Testar inicialização de todos os serviços"""
        rpg_service = RPGService()
        admin_service = AdminService(['admin1'])
        audio_service = AudioService()
        wwe_service = WWEDataService()
        
        # Verificar que todos foram inicializados corretamente
        self.assertIsNotNone(rpg_service)
        self.assertIsNotNone(admin_service)
        self.assertIsNotNone(audio_service)
        self.assertIsNotNone(wwe_service)
        
        # Verificar algumas funcionalidades básicas
        self.assertTrue(len(rpg_service.basic_actions) > 0)
        self.assertTrue(admin_service.is_admin('admin1'))
        self.assertIsInstance(audio_service.ydl_opts, dict)
        self.assertTrue(len(wwe_service.get_popular_wwe_characters()) > 0)

if __name__ == '__main__':
    # Configurar logging para testes
    import logging
    logging.basicConfig(level=logging.ERROR)  # Reduzir logs durante testes
    
    # Executar testes
    unittest.main(verbosity=2)

