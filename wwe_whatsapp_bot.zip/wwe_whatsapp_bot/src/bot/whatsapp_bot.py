import os
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
from pywa import WhatsApp
from pywa.types import Message, CallbackButton, Button
from dotenv import load_dotenv
import yt_dlp
from pydub import AudioSegment
import tempfile
import requests
from src.models.wwe_character import WWECharacter, PlayerCharacter, Match
from src.models.user import db

# Carregar variáveis de ambiente
load_dotenv()

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WWEWhatsAppBot:
    def __init__(self):
        self.token = os.getenv('WHATSAPP_TOKEN')
        self.verify_token = os.getenv('VERIFY_TOKEN')
        self.phone_number_id = os.getenv('PHONE_NUMBER_ID')
        self.admin_numbers = os.getenv('ADMIN_NUMBERS', '').split(',')
        self.audio_download_path = os.getenv('AUDIO_DOWNLOAD_PATH', './downloads/audio')
        self.max_audio_duration = int(os.getenv('MAX_AUDIO_DURATION', '300'))
        
        # Criar diretório de downloads se não existir
        os.makedirs(self.audio_download_path, exist_ok=True)
        
        # Inicializar cliente WhatsApp
        self.wa = WhatsApp(
            phone_id=self.phone_number_id,
            token=self.token,
            server=None,  # Será configurado quando integrado com Flask
            verify_token=self.verify_token
        )
        
        # Comandos disponíveis
        self.commands = {
            '!help': self.cmd_help,
            '!play': self.cmd_play,
            '!stop': self.cmd_stop,
            '!ban': self.cmd_ban,
            '!unban': self.cmd_unban,
            '!warn': self.cmd_warn,
            '!mute': self.cmd_mute,
            '!unmute': self.cmd_unmute,
            '!character': self.cmd_character,
            '!stats': self.cmd_stats,
            '!match': self.cmd_match,
            '!roll': self.cmd_roll,
            '!entrance': self.cmd_entrance,
            '!finisher': self.cmd_finisher,
            '!championship': self.cmd_championship,
            '!roster': self.cmd_roster,
            '!admin': self.cmd_admin
        }
        
        # Lista de usuários banidos (em memória, pode ser movido para BD)
        self.banned_users = set()
        self.muted_users = set()
        self.user_warnings = {}
        
        # Configurar handlers
        self.setup_handlers()
    
    def setup_handlers(self):
        """Configurar handlers para mensagens"""
        
        @self.wa.on_message()
        def handle_message(client: WhatsApp, msg: Message):
            try:
                self.process_message(msg)
            except Exception as e:
                logger.error(f"Erro ao processar mensagem: {e}")
                self.send_error_message(msg.from_user.wa_id, "Ocorreu um erro interno. Tente novamente.")
    
    def process_message(self, msg: Message):
        """Processar mensagem recebida"""
        user_id = msg.from_user.wa_id
        message_text = msg.text.body if msg.text else ""
        
        # Verificar se usuário está banido
        if user_id in self.banned_users:
            return
        
        # Verificar se usuário está mutado
        if user_id in self.muted_users:
            return
        
        # Verificar se é um comando
        if message_text.startswith('!'):
            self.handle_command(msg, message_text)
        else:
            # Verificar regras automáticas
            self.check_auto_moderation(msg, message_text)
    
    def handle_command(self, msg: Message, command_text: str):
        """Processar comandos"""
        parts = command_text.split(' ', 1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        
        if command in self.commands:
            try:
                self.commands[command](msg, args)
            except Exception as e:
                logger.error(f"Erro ao executar comando {command}: {e}")
                self.send_error_message(msg.from_user.wa_id, f"Erro ao executar comando {command}")
        else:
            self.send_message(msg.from_user.wa_id, 
                            f"Comando '{command}' não reconhecido. Use !help para ver os comandos disponíveis.")
    
    def check_auto_moderation(self, msg: Message, text: str):
        """Verificar regras de moderação automática"""
        user_id = msg.from_user.wa_id
        
        # Lista de palavras/frases proibidas (pode ser expandida)
        forbidden_words = ['spam', 'hack', 'cheat', 'bot']  # Exemplo básico
        
        text_lower = text.lower()
        for word in forbidden_words:
            if word in text_lower:
                self.warn_user(user_id, f"Uso de palavra proibida: {word}")
                break
        
        # Verificar spam (mensagens muito frequentes)
        # Implementação básica - pode ser melhorada
        if len(text) > 500:  # Mensagem muito longa
            self.warn_user(user_id, "Mensagem muito longa")
    
    def warn_user(self, user_id: str, reason: str):
        """Aplicar aviso a usuário"""
        if user_id not in self.user_warnings:
            self.user_warnings[user_id] = []
        
        self.user_warnings[user_id].append({
            'reason': reason,
            'timestamp': datetime.now()
        })
        
        warning_count = len(self.user_warnings[user_id])
        
        if warning_count >= 3:
            self.banned_users.add(user_id)
            self.send_admin_notification(f"Usuário {user_id} foi banido automaticamente após 3 avisos.")
        else:
            self.send_message(user_id, f"⚠️ AVISO {warning_count}/3: {reason}")
    
    # === COMANDOS ===
    
    def cmd_help(self, msg: Message, args: str):
        """Comando de ajuda"""
        help_text = """🤖 **WWE RPG Bot - Comandos Disponíveis**

**🎵 Áudio:**
!play <música> - Toca música de entrada
!stop - Para a música atual

**👮 Administração:**
!ban <@usuário> - Banir usuário (admin)
!unban <@usuário> - Desbanir usuário (admin)
!warn <@usuário> <motivo> - Avisar usuário (admin)
!mute <@usuário> - Mutar usuário (admin)
!unmute <@usuário> - Desmutar usuário (admin)

**🤼 RPG WWE:**
!character - Ver/criar seu personagem
!stats - Ver suas estatísticas
!match <tipo> - Iniciar uma luta
!roll <dado> - Rolar dados (ex: !roll d20)
!entrance - Fazer sua entrada
!finisher <oponente> - Usar movimento finalizador
!championship - Ver campeonatos
!roster - Ver roster completo

**ℹ️ Geral:**
!admin - Comandos de administração
!help - Esta mensagem

Desenvolvido por Manus AI 🚀"""
        
        self.send_message(msg.from_user.wa_id, help_text)
    
    def cmd_play(self, msg: Message, args: str):
        """Comando para tocar música"""
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !play <nome da música>")
            return
        
        try:
            self.send_message(msg.from_user.wa_id, f"🎵 Procurando por: {args}...")
            
            # Configurar yt-dlp
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': os.path.join(self.audio_download_path, '%(title)s.%(ext)s'),
                'noplaylist': True,
                'extractaudio': True,
                'audioformat': 'mp3',
                'audioquality': '192K',
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                # Buscar no YouTube
                search_query = f"ytsearch1:{args} entrance music"
                info = ydl.extract_info(search_query, download=False)
                
                if info and 'entries' in info and len(info['entries']) > 0:
                    video_info = info['entries'][0]
                    title = video_info.get('title', 'Música')
                    duration = video_info.get('duration', 0)
                    
                    if duration > self.max_audio_duration:
                        self.send_message(msg.from_user.wa_id, 
                                        f"❌ Música muito longa ({duration}s). Máximo: {self.max_audio_duration}s")
                        return
                    
                    # Download do áudio
                    ydl.download([video_info['webpage_url']])
                    
                    # Encontrar arquivo baixado
                    downloaded_file = None
                    for file in os.listdir(self.audio_download_path):
                        if title.replace('/', '_') in file:
                            downloaded_file = os.path.join(self.audio_download_path, file)
                            break
                    
                    if downloaded_file and os.path.exists(downloaded_file):
                        # Converter para formato WhatsApp se necessário
                        audio_file = self.convert_audio_for_whatsapp(downloaded_file)
                        
                        # Enviar áudio
                        with open(audio_file, 'rb') as audio:
                            self.wa.send_audio(
                                to=msg.from_user.wa_id,
                                audio=audio.read(),
                                caption=f"🎵 {title}"
                            )
                        
                        # Limpar arquivo temporário
                        os.remove(audio_file)
                        if audio_file != downloaded_file:
                            os.remove(downloaded_file)
                        
                        self.send_message(msg.from_user.wa_id, f"✅ Tocando: {title}")
                    else:
                        self.send_message(msg.from_user.wa_id, "❌ Erro ao baixar a música")
                else:
                    self.send_message(msg.from_user.wa_id, f"❌ Música '{args}' não encontrada")
                    
        except Exception as e:
            logger.error(f"Erro no comando play: {e}")
            self.send_message(msg.from_user.wa_id, "❌ Erro ao processar música. Tente novamente.")
    
    def convert_audio_for_whatsapp(self, input_file: str) -> str:
        """Converter áudio para formato compatível com WhatsApp"""
        try:
            audio = AudioSegment.from_file(input_file)
            
            # Limitar duração
            if len(audio) > self.max_audio_duration * 1000:
                audio = audio[:self.max_audio_duration * 1000]
            
            # Converter para formato adequado
            output_file = input_file.rsplit('.', 1)[0] + '_converted.ogg'
            audio.export(output_file, format="ogg", codec="libopus")
            
            return output_file
        except Exception as e:
            logger.error(f"Erro ao converter áudio: {e}")
            return input_file
    
    def cmd_stop(self, msg: Message, args: str):
        """Comando para parar música"""
        self.send_message(msg.from_user.wa_id, "⏹️ Música parada!")
    
    def cmd_ban(self, msg: Message, args: str):
        """Comando para banir usuário (apenas admins)"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem usar este comando")
            return
        
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !ban <@usuário> ou !ban <número>")
            return
        
        # Extrair número do usuário (implementação básica)
        target_user = args.strip().replace('@', '').replace('+', '')
        
        self.banned_users.add(target_user)
        self.send_message(msg.from_user.wa_id, f"🔨 Usuário {target_user} foi banido")
        self.send_admin_notification(f"Usuário {target_user} foi banido por {msg.from_user.wa_id}")
    
    def cmd_unban(self, msg: Message, args: str):
        """Comando para desbanir usuário (apenas admins)"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem usar este comando")
            return
        
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !unban <@usuário> ou !unban <número>")
            return
        
        target_user = args.strip().replace('@', '').replace('+', '')
        
        if target_user in self.banned_users:
            self.banned_users.remove(target_user)
            self.send_message(msg.from_user.wa_id, f"✅ Usuário {target_user} foi desbanido")
        else:
            self.send_message(msg.from_user.wa_id, f"❌ Usuário {target_user} não está banido")
    
    def cmd_warn(self, msg: Message, args: str):
        """Comando para avisar usuário (apenas admins)"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem usar este comando")
            return
        
        parts = args.split(' ', 1)
        if len(parts) < 2:
            self.send_message(msg.from_user.wa_id, "❌ Use: !warn <@usuário> <motivo>")
            return
        
        target_user = parts[0].strip().replace('@', '').replace('+', '')
        reason = parts[1]
        
        self.warn_user(target_user, reason)
        self.send_message(msg.from_user.wa_id, f"⚠️ Aviso aplicado a {target_user}")
    
    def cmd_mute(self, msg: Message, args: str):
        """Comando para mutar usuário (apenas admins)"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem usar este comando")
            return
        
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !mute <@usuário>")
            return
        
        target_user = args.strip().replace('@', '').replace('+', '')
        self.muted_users.add(target_user)
        self.send_message(msg.from_user.wa_id, f"🔇 Usuário {target_user} foi mutado")
    
    def cmd_unmute(self, msg: Message, args: str):
        """Comando para desmutar usuário (apenas admins)"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem usar este comando")
            return
        
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !unmute <@usuário>")
            return
        
        target_user = args.strip().replace('@', '').replace('+', '')
        if target_user in self.muted_users:
            self.muted_users.remove(target_user)
            self.send_message(msg.from_user.wa_id, f"🔊 Usuário {target_user} foi desmutado")
        else:
            self.send_message(msg.from_user.wa_id, f"❌ Usuário {target_user} não está mutado")
    
    def cmd_character(self, msg: Message, args: str):
        """Comando para gerenciar personagem"""
        user_id = msg.from_user.wa_id
        
        # Buscar personagem do usuário
        character = PlayerCharacter.query.filter_by(whatsapp_number=user_id).first()
        
        if not character:
            if args:
                # Criar novo personagem
                character = PlayerCharacter(
                    whatsapp_number=user_id,
                    character_name=args[:100]
                )
                db.session.add(character)
                db.session.commit()
                
                self.send_message(user_id, f"✅ Personagem '{args}' criado com sucesso!")
            else:
                self.send_message(user_id, "❌ Você não tem um personagem. Use: !character <nome>")
        else:
            # Mostrar informações do personagem
            char_info = f"""🤼 **{character.character_name}**

📊 **Estatísticas:**
• Nível: {character.level}
• Experiência: {character.experience}
• Vida: {character.health}/{character.max_health}

💪 **Atributos:**
• Força: {character.strength}
• Velocidade: {character.speed}
• Carisma: {character.charisma}
• Técnica: {character.technique}
• Resistência: {character.stamina}

🏆 **Carreira:**
• Vitórias: {character.wins}
• Derrotas: {character.losses}
• Finalizadora: {character.finisher_move or 'Não definida'}
• Música de Entrada: {character.entrance_music or 'Não definida'}"""
            
            self.send_message(user_id, char_info)
    
    def cmd_stats(self, msg: Message, args: str):
        """Comando para ver estatísticas"""
        self.cmd_character(msg, "")  # Reutilizar lógica do character
    
    def cmd_match(self, msg: Message, args: str):
        """Comando para iniciar luta"""
        if not args:
            self.send_message(msg.from_user.wa_id, "❌ Use: !match <singles|tag|royal_rumble>")
            return
        
        match_type = args.lower()
        valid_types = ['singles', 'tag', 'royal_rumble']
        
        if match_type not in valid_types:
            self.send_message(msg.from_user.wa_id, f"❌ Tipos válidos: {', '.join(valid_types)}")
            return
        
        # Criar nova luta
        match = Match(
            match_type=match_type,
            participants=json.dumps([msg.from_user.wa_id]),
            scheduled_time=datetime.now()
        )
        db.session.add(match)
        db.session.commit()
        
        self.send_message(msg.from_user.wa_id, f"🤼 Luta {match_type} criada! ID: {match.id}")
    
    def cmd_roll(self, msg: Message, args: str):
        """Comando para rolar dados"""
        import random
        
        if not args:
            # Rolar d20 por padrão
            result = random.randint(1, 20)
            self.send_message(msg.from_user.wa_id, f"🎲 Você rolou um d20: **{result}**")
        else:
            try:
                if args.lower().startswith('d'):
                    sides = int(args[1:])
                    result = random.randint(1, sides)
                    self.send_message(msg.from_user.wa_id, f"🎲 Você rolou um {args}: **{result}**")
                else:
                    self.send_message(msg.from_user.wa_id, "❌ Use: !roll d<número> (ex: !roll d20)")
            except ValueError:
                self.send_message(msg.from_user.wa_id, "❌ Formato inválido. Use: !roll d<número>")
    
    def cmd_entrance(self, msg: Message, args: str):
        """Comando para fazer entrada"""
        user_id = msg.from_user.wa_id
        character = PlayerCharacter.query.filter_by(whatsapp_number=user_id).first()
        
        if not character:
            self.send_message(user_id, "❌ Você precisa criar um personagem primeiro! Use: !character <nome>")
            return
        
        entrance_text = f"""🎵🚶‍♂️ **ENTRADA ÉPICA!** 🚶‍♂️🎵

*As luzes se apagam...*
*A música começa a tocar...*

🔥 **{character.character_name}** está fazendo sua entrada!

*A multidão vai à loucura!*
*Os holofotes iluminam o ringue!*

🤼 {character.character_name} está pronto para a ação!"""
        
        self.send_message(user_id, entrance_text)
        
        # Se tem música de entrada, tocar
        if character.entrance_music:
            self.cmd_play(msg, character.entrance_music)
    
    def cmd_finisher(self, msg: Message, args: str):
        """Comando para usar finalizadora"""
        user_id = msg.from_user.wa_id
        character = PlayerCharacter.query.filter_by(whatsapp_number=user_id).first()
        
        if not character:
            self.send_message(user_id, "❌ Você precisa criar um personagem primeiro!")
            return
        
        if not args:
            self.send_message(user_id, "❌ Use: !finisher <oponente>")
            return
        
        finisher = character.finisher_move or "Movimento Especial"
        
        finisher_text = f"""💥 **FINALIZADORA!** 💥

🤼 {character.character_name} está preparando...

⚡ **{finisher.upper()}** ⚡

🎯 Alvo: {args}

*O público está de pé!*
*Será que vai conseguir?*

🎲 Role os dados para ver o resultado!"""
        
        self.send_message(user_id, finisher_text)
    
    def cmd_championship(self, msg: Message, args: str):
        """Comando para ver campeonatos"""
        championships = """🏆 **CAMPEONATOS WWE RPG** 🏆

👑 **WWE Championship**
• Atual Campeão: Vago
• Defesas: 0

🌟 **Universal Championship**
• Atual Campeão: Vago
• Defesas: 0

👥 **Tag Team Championship**
• Atuais Campeões: Vago
• Defesas: 0

👩 **Women's Championship**
• Atual Campeã: Vago
• Defesas: 0

🔥 **Intercontinental Championship**
• Atual Campeão: Vago
• Defesas: 0

Para disputar um campeonato, organize uma luta com !match"""
        
        self.send_message(msg.from_user.wa_id, championships)
    
    def cmd_roster(self, msg: Message, args: str):
        """Comando para ver roster"""
        characters = PlayerCharacter.query.filter_by(is_active=True).all()
        
        if not characters:
            self.send_message(msg.from_user.wa_id, "❌ Nenhum personagem ativo no roster")
            return
        
        roster_text = "🤼 **ROSTER WWE RPG** 🤼\n\n"
        
        for char in characters:
            wins = char.wins
            losses = char.losses
            total_matches = wins + losses
            win_rate = (wins / total_matches * 100) if total_matches > 0 else 0
            
            roster_text += f"• **{char.character_name}** (Nível {char.level})\n"
            roster_text += f"  📊 {wins}W-{losses}L ({win_rate:.1f}%)\n\n"
        
        self.send_message(msg.from_user.wa_id, roster_text)
    
    def cmd_admin(self, msg: Message, args: str):
        """Comando para mostrar comandos de admin"""
        if msg.from_user.wa_id not in self.admin_numbers:
            self.send_message(msg.from_user.wa_id, "❌ Apenas administradores podem ver este menu")
            return
        
        admin_text = """👮 **COMANDOS DE ADMINISTRAÇÃO** 👮

**Moderação:**
• !ban <usuário> - Banir usuário
• !unban <usuário> - Desbanir usuário
• !warn <usuário> <motivo> - Avisar usuário
• !mute <usuário> - Mutar usuário
• !unmute <usuário> - Desmutar usuário

**RPG:**
• !match <tipo> - Criar luta
• !championship - Gerenciar campeonatos

**Sistema:**
• !stats - Ver estatísticas do bot
• !backup - Fazer backup do banco de dados

Use com responsabilidade! 🛡️"""
        
        self.send_message(msg.from_user.wa_id, admin_text)
    
    # === MÉTODOS AUXILIARES ===
    
    def send_message(self, to: str, text: str):
        """Enviar mensagem de texto"""
        try:
            self.wa.send_message(to=to, text=text)
        except Exception as e:
            logger.error(f"Erro ao enviar mensagem: {e}")
    
    def send_error_message(self, to: str, error: str):
        """Enviar mensagem de erro"""
        self.send_message(to, f"❌ {error}")
    
    def send_admin_notification(self, message: str):
        """Enviar notificação para administradores"""
        for admin in self.admin_numbers:
            if admin.strip():
                self.send_message(admin.strip(), f"🚨 **ADMIN NOTIFICATION** 🚨\n{message}")
    
    def get_webhook_handler(self):
        """Retornar handler para webhook do Flask"""
        return self.wa.webhook_handler

