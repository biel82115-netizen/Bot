from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class WWECharacter(db.Model):
    __tablename__ = 'wwe_characters'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    real_name = db.Column(db.String(100))
    nickname = db.Column(db.String(100))
    brand = db.Column(db.String(50))  # RAW, SmackDown, NXT, etc.
    height = db.Column(db.String(20))
    weight = db.Column(db.String(20))
    hometown = db.Column(db.String(100))
    signature_moves = db.Column(db.Text)  # JSON string with moves
    finisher_moves = db.Column(db.Text)  # JSON string with finishers
    entrance_music = db.Column(db.String(200))
    entrance_music_url = db.Column(db.String(500))
    
    # RPG Stats
    strength = db.Column(db.Integer, default=50)
    speed = db.Column(db.Integer, default=50)
    charisma = db.Column(db.Integer, default=50)
    technique = db.Column(db.Integer, default=50)
    stamina = db.Column(db.Integer, default=50)
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    championship_history = db.Column(db.Text)  # JSON string
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<WWECharacter {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'real_name': self.real_name,
            'nickname': self.nickname,
            'brand': self.brand,
            'height': self.height,
            'weight': self.weight,
            'hometown': self.hometown,
            'signature_moves': self.signature_moves,
            'finisher_moves': self.finisher_moves,
            'entrance_music': self.entrance_music,
            'entrance_music_url': self.entrance_music_url,
            'strength': self.strength,
            'speed': self.speed,
            'charisma': self.charisma,
            'technique': self.technique,
            'stamina': self.stamina,
            'is_active': self.is_active,
            'championship_history': self.championship_history
        }

class PlayerCharacter(db.Model):
    __tablename__ = 'player_characters'
    
    id = db.Column(db.Integer, primary_key=True)
    whatsapp_number = db.Column(db.String(20), nullable=False)
    character_name = db.Column(db.String(100), nullable=False)
    
    # RPG Stats
    level = db.Column(db.Integer, default=1)
    experience = db.Column(db.Integer, default=0)
    health = db.Column(db.Integer, default=100)
    max_health = db.Column(db.Integer, default=100)
    
    # WWE Stats
    strength = db.Column(db.Integer, default=10)
    speed = db.Column(db.Integer, default=10)
    charisma = db.Column(db.Integer, default=10)
    technique = db.Column(db.Integer, default=10)
    stamina = db.Column(db.Integer, default=10)
    
    # Career
    wins = db.Column(db.Integer, default=0)
    losses = db.Column(db.Integer, default=0)
    championships_held = db.Column(db.Text)  # JSON string
    signature_moves = db.Column(db.Text)  # JSON string
    finisher_move = db.Column(db.String(100))
    entrance_music = db.Column(db.String(200))
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    current_storyline = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<PlayerCharacter {self.character_name} ({self.whatsapp_number})>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'whatsapp_number': self.whatsapp_number,
            'character_name': self.character_name,
            'level': self.level,
            'experience': self.experience,
            'health': self.health,
            'max_health': self.max_health,
            'strength': self.strength,
            'speed': self.speed,
            'charisma': self.charisma,
            'technique': self.technique,
            'stamina': self.stamina,
            'wins': self.wins,
            'losses': self.losses,
            'championships_held': self.championships_held,
            'signature_moves': self.signature_moves,
            'finisher_move': self.finisher_move,
            'entrance_music': self.entrance_music,
            'is_active': self.is_active,
            'current_storyline': self.current_storyline
        }

class Match(db.Model):
    __tablename__ = 'matches'
    
    id = db.Column(db.Integer, primary_key=True)
    match_type = db.Column(db.String(50), nullable=False)  # Singles, Tag Team, Royal Rumble, etc.
    participants = db.Column(db.Text, nullable=False)  # JSON string with participant IDs
    winner_id = db.Column(db.Integer)
    match_result = db.Column(db.Text)  # JSON string with detailed results
    
    # Match Settings
    stipulation = db.Column(db.String(200))  # Cage Match, Ladder Match, etc.
    championship_on_line = db.Column(db.String(100))
    
    # Timestamps
    scheduled_time = db.Column(db.DateTime)
    started_at = db.Column(db.DateTime)
    ended_at = db.Column(db.DateTime)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Match {self.id} - {self.match_type}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'match_type': self.match_type,
            'participants': self.participants,
            'winner_id': self.winner_id,
            'match_result': self.match_result,
            'stipulation': self.stipulation,
            'championship_on_line': self.championship_on_line,
            'scheduled_time': self.scheduled_time.isoformat() if self.scheduled_time else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'ended_at': self.ended_at.isoformat() if self.ended_at else None
        }

