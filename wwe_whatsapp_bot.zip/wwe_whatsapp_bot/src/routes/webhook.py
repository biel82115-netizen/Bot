from flask import Blueprint, request, jsonify
from src.bot.whatsapp_bot import WWEWhatsAppBot
import logging

logger = logging.getLogger(__name__)

# Criar blueprint para webhook
webhook_bp = Blueprint('webhook', __name__)

# Instância global do bot (será inicializada quando necessário)
bot_instance = None

def get_bot_instance():
    """Obter instância do bot (singleton)"""
    global bot_instance
    if bot_instance is None:
        bot_instance = WWEWhatsAppBot()
    return bot_instance

@webhook_bp.route('/webhook', methods=['GET', 'POST'])
def webhook():
    """Endpoint para webhook do WhatsApp"""
    try:
        if request.method == 'GET':
            # Verificação do webhook
            verify_token = request.args.get('hub.verify_token')
            challenge = request.args.get('hub.challenge')
            
            bot = get_bot_instance()
            if verify_token == bot.verify_token:
                logger.info("Webhook verificado com sucesso")
                return challenge
            else:
                logger.error("Token de verificação inválido")
                return "Token inválido", 403
        
        elif request.method == 'POST':
            # Processar mensagem recebida
            bot = get_bot_instance()
            
            # Usar o handler do PyWa
            handler = bot.get_webhook_handler()
            return handler(request)
            
    except Exception as e:
        logger.error(f"Erro no webhook: {e}")
        return jsonify({"error": "Erro interno"}), 500

@webhook_bp.route('/webhook/status', methods=['GET'])
def webhook_status():
    """Endpoint para verificar status do bot"""
    try:
        bot = get_bot_instance()
        return jsonify({
            "status": "online",
            "bot_name": "WWE RPG Bot",
            "version": "1.0.0",
            "commands_available": len(bot.commands),
            "banned_users": len(bot.banned_users),
            "muted_users": len(bot.muted_users)
        })
    except Exception as e:
        logger.error(f"Erro ao verificar status: {e}")
        return jsonify({"error": "Erro ao verificar status"}), 500

@webhook_bp.route('/webhook/admin/stats', methods=['GET'])
def admin_stats():
    """Endpoint para estatísticas administrativas"""
    try:
        bot = get_bot_instance()
        
        # Verificar se é admin (implementação básica)
        # Em produção, implementar autenticação adequada
        
        return jsonify({
            "total_commands": len(bot.commands),
            "banned_users": list(bot.banned_users),
            "muted_users": list(bot.muted_users),
            "user_warnings": {k: len(v) for k, v in bot.user_warnings.items()},
            "admin_numbers": len(bot.admin_numbers)
        })
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas: {e}")
        return jsonify({"error": "Erro ao obter estatísticas"}), 500

