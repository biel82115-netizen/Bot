import json
import random
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from src.models.wwe_character import PlayerCharacter, WWECharacter, Match, db

logger = logging.getLogger(__name__)

@dataclass
class BattleAction:
    """Ação de batalha"""
    name: str
    damage_range: Tuple[int, int]
    accuracy: int  # 0-100
    stamina_cost: int
    description: str
    requirements: Dict = None  # ex: {'strength': 50}

@dataclass
class BattleResult:
    """Resultado de uma ação de batalha"""
    success: bool
    damage_dealt: int
    critical_hit: bool
    description: str
    attacker_stamina_left: int
    defender_health_left: int

class RPGService:
    """Serviço de RPG WWE com sistema de batalhas e progressão"""
    
    def __init__(self):
        # Ações básicas disponíveis para todos
        self.basic_actions = [
            BattleAction("Soco", (5, 15), 85, 5, "Um soco básico"),
            BattleAction("Chute", (8, 18), 80, 7, "Um chute poderoso"),
            BattleAction("Grapple", (10, 20), 75, 10, "Agarrar o oponente"),
            BattleAction("Dropkick", (12, 22), 70, 12, "Um dropkick voador"),
            BattleAction("Clothesline", (15, 25), 65, 15, "Uma clothesline devastadora")
        ]
        
        # Ações especiais baseadas em atributos
        self.special_actions = [
            BattleAction("Powerbomb", (25, 40), 60, 25, "Movimento de força bruta", 
                        {'strength': 70}),
            BattleAction("Hurricanrana", (20, 30), 70, 20, "Movimento acrobático", 
                        {'speed': 70}),
            BattleAction("Submission Hold", (15, 35), 75, 20, "Chave de submissão", 
                        {'technique': 70}),
            BattleAction("Taunt", (0, 0), 95, 5, "Provocar o oponente (reduz moral)", 
                        {'charisma': 60})
        ]
        
        # Tipos de luta e suas regras
        self.match_types = {
            'singles': {
                'name': 'Singles Match',
                'participants': 2,
                'win_conditions': ['pinfall', 'submission', 'knockout'],
                'time_limit': 20,  # turnos
                'description': 'Luta individual 1 vs 1'
            },
            'triple_threat': {
                'name': 'Triple Threat Match',
                'participants': 3,
                'win_conditions': ['pinfall', 'submission', 'knockout'],
                'time_limit': 25,
                'description': 'Luta de três lutadores'
            },
            'battle_royal': {
                'name': 'Battle Royal',
                'participants': 10,
                'win_conditions': ['elimination'],
                'time_limit': 30,
                'description': 'Luta eliminatória com múltiplos participantes'
            },
            'ladder': {
                'name': 'Ladder Match',
                'participants': 2,
                'win_conditions': ['ladder_climb'],
                'time_limit': 25,
                'description': 'Luta com escadas para alcançar objeto suspenso'
            },
            'cage': {
                'name': 'Steel Cage Match',
                'participants': 2,
                'win_conditions': ['pinfall', 'submission', 'escape'],
                'time_limit': 20,
                'description': 'Luta dentro de uma gaiola de aço'
            }
        }
        
        # Sistema de experiência e níveis
        self.xp_table = {
            1: 0, 2: 100, 3: 250, 4: 450, 5: 700,
            6: 1000, 7: 1350, 8: 1750, 9: 2200, 10: 2700,
            11: 3250, 12: 3850, 13: 4500, 14: 5200, 15: 5950,
            16: 6750, 17: 7600, 18: 8500, 19: 9450, 20: 10450
        }
    
    def create_character(self, whatsapp_number: str, character_name: str, 
                        starting_stats: Optional[Dict] = None) -> Dict:
        """Criar novo personagem de jogador"""
        try:
            # Verificar se já existe personagem
            existing = PlayerCharacter.query.filter_by(whatsapp_number=whatsapp_number).first()
            if existing:
                return {'success': False, 'error': 'Você já possui um personagem'}
            
            # Stats iniciais padrão
            default_stats = {
                'strength': 10,
                'speed': 10,
                'charisma': 10,
                'technique': 10,
                'stamina': 10
            }
            
            if starting_stats:
                # Validar que a soma não excede o limite
                total_points = sum(starting_stats.values())
                if total_points > 60:  # Limite inicial
                    return {'success': False, 'error': 'Total de pontos excede o limite (60)'}
                default_stats.update(starting_stats)
            
            # Criar personagem
            character = PlayerCharacter(
                whatsapp_number=whatsapp_number,
                character_name=character_name,
                **default_stats
            )
            
            db.session.add(character)
            db.session.commit()
            
            return {
                'success': True,
                'character': character.to_dict(),
                'message': f'Personagem "{character_name}" criado com sucesso!'
            }
            
        except Exception as e:
            logger.error(f"Erro ao criar personagem: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def get_character(self, whatsapp_number: str) -> Optional[PlayerCharacter]:
        """Obter personagem do jogador"""
        return PlayerCharacter.query.filter_by(
            whatsapp_number=whatsapp_number, 
            is_active=True
        ).first()
    
    def level_up_character(self, character: PlayerCharacter) -> Dict:
        """Subir nível do personagem se possível"""
        try:
            current_level = character.level
            required_xp = self.xp_table.get(current_level + 1)
            
            if not required_xp:
                return {'success': False, 'error': 'Nível máximo atingido'}
            
            if character.experience < required_xp:
                return {'success': False, 'error': 'XP insuficiente'}
            
            # Subir nível
            character.level += 1
            
            # Ganhar pontos de atributo (3 pontos por nível)
            stat_points = 3
            
            # Aumentar vida máxima
            character.max_health += 10
            character.health = character.max_health  # Curar completamente
            
            db.session.commit()
            
            return {
                'success': True,
                'new_level': character.level,
                'stat_points_gained': stat_points,
                'health_increase': 10,
                'message': f'🎉 {character.character_name} subiu para o nível {character.level}!'
            }
            
        except Exception as e:
            logger.error(f"Erro ao subir nível: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def allocate_stat_points(self, character: PlayerCharacter, stat_allocation: Dict) -> Dict:
        """Alocar pontos de atributo"""
        try:
            # Calcular pontos disponíveis baseado no nível
            total_allocated = (character.strength + character.speed + character.charisma + 
                             character.technique + character.stamina)
            base_points = 50  # Pontos base
            level_points = (character.level - 1) * 3  # 3 pontos por nível
            available_points = base_points + level_points - total_allocated
            
            # Verificar se tem pontos suficientes
            points_to_spend = sum(stat_allocation.values())
            if points_to_spend > available_points:
                return {'success': False, 'error': f'Pontos insuficientes. Disponíveis: {available_points}'}
            
            # Aplicar pontos
            character.strength += stat_allocation.get('strength', 0)
            character.speed += stat_allocation.get('speed', 0)
            character.charisma += stat_allocation.get('charisma', 0)
            character.technique += stat_allocation.get('technique', 0)
            character.stamina += stat_allocation.get('stamina', 0)
            
            # Limitar stats máximos (100)
            character.strength = min(character.strength, 100)
            character.speed = min(character.speed, 100)
            character.charisma = min(character.charisma, 100)
            character.technique = min(character.technique, 100)
            character.stamina = min(character.stamina, 100)
            
            db.session.commit()
            
            return {
                'success': True,
                'points_spent': points_to_spend,
                'remaining_points': available_points - points_to_spend,
                'new_stats': {
                    'strength': character.strength,
                    'speed': character.speed,
                    'charisma': character.charisma,
                    'technique': character.technique,
                    'stamina': character.stamina
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao alocar pontos: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def start_match(self, match_type: str, participants: List[str], 
                   championship: Optional[str] = None) -> Dict:
        """Iniciar uma nova luta"""
        try:
            if match_type not in self.match_types:
                return {'success': False, 'error': 'Tipo de luta inválido'}
            
            match_config = self.match_types[match_type]
            
            if len(participants) != match_config['participants']:
                return {'success': False, 'error': f'Número incorreto de participantes. Esperado: {match_config["participants"]}'}
            
            # Verificar se todos os participantes têm personagens
            characters = []
            for participant in participants:
                char = self.get_character(participant)
                if not char:
                    return {'success': False, 'error': f'Participante {participant} não tem personagem'}
                if char.health <= 0:
                    return {'success': False, 'error': f'{char.character_name} está incapacitado'}
                characters.append(char)
            
            # Criar registro da luta
            match = Match(
                match_type=match_type,
                participants=json.dumps(participants),
                championship_on_line=championship,
                scheduled_time=datetime.now(),
                started_at=datetime.now()
            )
            
            db.session.add(match)
            db.session.commit()
            
            # Criar estado inicial da batalha
            battle_state = {
                'match_id': match.id,
                'match_type': match_type,
                'participants': [char.to_dict() for char in characters],
                'current_turn': 0,
                'turn_order': list(range(len(characters))),
                'match_config': match_config,
                'turn_count': 0,
                'status': 'active',
                'championship': championship
            }
            
            return {
                'success': True,
                'match_id': match.id,
                'battle_state': battle_state,
                'message': f'🤼 {match_config["name"]} iniciada! ID: {match.id}'
            }
            
        except Exception as e:
            logger.error(f"Erro ao iniciar luta: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def execute_battle_action(self, match_id: int, attacker_id: str, 
                            action_name: str, target_id: Optional[str] = None) -> Dict:
        """Executar ação de batalha"""
        try:
            # Buscar luta
            match = Match.query.get(match_id)
            if not match:
                return {'success': False, 'error': 'Luta não encontrada'}
            
            # Buscar personagens
            attacker = self.get_character(attacker_id)
            if not attacker:
                return {'success': False, 'error': 'Personagem atacante não encontrado'}
            
            # Encontrar ação
            action = self._find_action(action_name, attacker)
            if not action:
                return {'success': False, 'error': 'Ação não encontrada ou indisponível'}
            
            # Verificar stamina
            if attacker.stamina < action.stamina_cost:
                return {'success': False, 'error': 'Stamina insuficiente'}
            
            # Executar ação
            if target_id:
                target = self.get_character(target_id)
                if not target:
                    return {'success': False, 'error': 'Alvo não encontrado'}
                
                result = self._execute_attack(attacker, target, action)
            else:
                # Ação sem alvo (ex: taunt)
                result = self._execute_self_action(attacker, action)
            
            # Atualizar banco de dados
            db.session.commit()
            
            return {
                'success': True,
                'battle_result': result,
                'match_id': match_id
            }
            
        except Exception as e:
            logger.error(f"Erro ao executar ação: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def _find_action(self, action_name: str, character: PlayerCharacter) -> Optional[BattleAction]:
        """Encontrar ação disponível para o personagem"""
        # Verificar ações básicas
        for action in self.basic_actions:
            if action.name.lower() == action_name.lower():
                return action
        
        # Verificar ações especiais
        for action in self.special_actions:
            if action.name.lower() == action_name.lower():
                # Verificar requisitos
                if action.requirements:
                    for stat, required_value in action.requirements.items():
                        char_stat = getattr(character, stat, 0)
                        if char_stat < required_value:
                            return None
                return action
        
        return None
    
    def _execute_attack(self, attacker: PlayerCharacter, target: PlayerCharacter, 
                       action: BattleAction) -> BattleResult:
        """Executar ataque entre personagens"""
        # Calcular chance de acerto
        hit_chance = action.accuracy
        
        # Modificadores baseados em stats
        speed_diff = attacker.speed - target.speed
        hit_chance += speed_diff // 5  # +1% por 5 pontos de diferença
        
        # Rolar para acerto
        hit_roll = random.randint(1, 100)
        success = hit_roll <= hit_chance
        
        damage_dealt = 0
        critical_hit = False
        
        if success:
            # Calcular dano base
            min_damage, max_damage = action.damage_range
            base_damage = random.randint(min_damage, max_damage)
            
            # Modificadores de dano
            strength_bonus = attacker.strength // 10  # +1 dano por 10 pontos de força
            technique_bonus = attacker.technique // 20  # +1 dano por 20 pontos de técnica
            
            damage_dealt = base_damage + strength_bonus + technique_bonus
            
            # Chance de crítico
            crit_chance = attacker.charisma // 10  # 1% por 10 pontos de carisma
            if random.randint(1, 100) <= crit_chance:
                critical_hit = True
                damage_dealt = int(damage_dealt * 1.5)
            
            # Aplicar dano
            target.health = max(0, target.health - damage_dealt)
        
        # Consumir stamina do atacante
        attacker.stamina = max(0, attacker.stamina - action.stamina_cost)
        
        # Gerar descrição
        if success:
            desc = f"{attacker.character_name} acerta {action.name} em {target.character_name}"
            if critical_hit:
                desc += " (CRÍTICO!)"
            desc += f" causando {damage_dealt} de dano!"
        else:
            desc = f"{attacker.character_name} erra {action.name} em {target.character_name}!"
        
        return BattleResult(
            success=success,
            damage_dealt=damage_dealt,
            critical_hit=critical_hit,
            description=desc,
            attacker_stamina_left=attacker.stamina,
            defender_health_left=target.health
        )
    
    def _execute_self_action(self, character: PlayerCharacter, action: BattleAction) -> BattleResult:
        """Executar ação em si mesmo (ex: taunt, recuperação)"""
        # Consumir stamina
        character.stamina = max(0, character.stamina - action.stamina_cost)
        
        desc = f"{character.character_name} usa {action.name}!"
        
        return BattleResult(
            success=True,
            damage_dealt=0,
            critical_hit=False,
            description=desc,
            attacker_stamina_left=character.stamina,
            defender_health_left=character.health
        )
    
    def finish_match(self, match_id: int, winner_id: str, win_condition: str) -> Dict:
        """Finalizar luta e distribuir recompensas"""
        try:
            match = Match.query.get(match_id)
            if not match:
                return {'success': False, 'error': 'Luta não encontrada'}
            
            # Atualizar registro da luta
            match.ended_at = datetime.now()
            match.winner_id = winner_id
            match.match_result = json.dumps({
                'win_condition': win_condition,
                'duration': (match.ended_at - match.started_at).total_seconds()
            })
            
            # Distribuir XP e recompensas
            participants = json.loads(match.participants)
            winner = self.get_character(winner_id)
            
            if winner:
                # XP para o vencedor
                base_xp = 50
                match_type_bonus = {'singles': 10, 'triple_threat': 15, 'battle_royal': 25}.get(match.match_type, 10)
                winner_xp = base_xp + match_type_bonus
                
                winner.experience += winner_xp
                winner.wins += 1
                
                # Verificar level up
                level_up_result = self.level_up_character(winner)
            
            # XP para perdedores
            for participant in participants:
                if participant != winner_id:
                    loser = self.get_character(participant)
                    if loser:
                        loser.experience += 20  # XP de consolação
                        loser.losses += 1
            
            db.session.commit()
            
            return {
                'success': True,
                'winner': winner.character_name if winner else 'Desconhecido',
                'xp_gained': winner_xp if winner else 0,
                'level_up': level_up_result if winner and level_up_result.get('success') else None,
                'match_duration': (match.ended_at - match.started_at).total_seconds()
            }
            
        except Exception as e:
            logger.error(f"Erro ao finalizar luta: {e}")
            db.session.rollback()
            return {'success': False, 'error': str(e)}
    
    def get_available_actions(self, character: PlayerCharacter) -> List[Dict]:
        """Obter ações disponíveis para o personagem"""
        available = []
        
        # Ações básicas
        for action in self.basic_actions:
            if character.stamina >= action.stamina_cost:
                available.append({
                    'name': action.name,
                    'damage_range': action.damage_range,
                    'accuracy': action.accuracy,
                    'stamina_cost': action.stamina_cost,
                    'description': action.description,
                    'type': 'basic'
                })
        
        # Ações especiais
        for action in self.special_actions:
            if character.stamina >= action.stamina_cost:
                # Verificar requisitos
                can_use = True
                if action.requirements:
                    for stat, required_value in action.requirements.items():
                        char_stat = getattr(character, stat, 0)
                        if char_stat < required_value:
                            can_use = False
                            break
                
                if can_use:
                    available.append({
                        'name': action.name,
                        'damage_range': action.damage_range,
                        'accuracy': action.accuracy,
                        'stamina_cost': action.stamina_cost,
                        'description': action.description,
                        'requirements': action.requirements,
                        'type': 'special'
                    })
        
        return available
    
    def roll_dice(self, dice_notation: str) -> Dict:
        """Rolar dados (ex: d20, 2d6, d100)"""
        try:
            # Parse da notação de dados
            if dice_notation.lower().startswith('d'):
                # Formato: d20
                num_dice = 1
                sides = int(dice_notation[1:])
            elif 'd' in dice_notation.lower():
                # Formato: 2d6
                parts = dice_notation.lower().split('d')
                num_dice = int(parts[0])
                sides = int(parts[1])
            else:
                return {'success': False, 'error': 'Formato inválido. Use: d20 ou 2d6'}
            
            # Validações
            if num_dice < 1 or num_dice > 10:
                return {'success': False, 'error': 'Número de dados deve ser entre 1 e 10'}
            if sides < 2 or sides > 100:
                return {'success': False, 'error': 'Número de lados deve ser entre 2 e 100'}
            
            # Rolar dados
            rolls = [random.randint(1, sides) for _ in range(num_dice)]
            total = sum(rolls)
            
            return {
                'success': True,
                'dice_notation': dice_notation,
                'num_dice': num_dice,
                'sides': sides,
                'rolls': rolls,
                'total': total,
                'description': f"Rolou {dice_notation}: {rolls} = {total}"
            }
            
        except ValueError:
            return {'success': False, 'error': 'Formato inválido. Use: d20 ou 2d6'}
        except Exception as e:
            logger.error(f"Erro ao rolar dados: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_leaderboard(self, category: str = 'wins') -> List[Dict]:
        """Obter ranking de jogadores"""
        try:
            if category == 'wins':
                characters = PlayerCharacter.query.filter_by(is_active=True).order_by(PlayerCharacter.wins.desc()).limit(10).all()
            elif category == 'level':
                characters = PlayerCharacter.query.filter_by(is_active=True).order_by(PlayerCharacter.level.desc()).limit(10).all()
            elif category == 'experience':
                characters = PlayerCharacter.query.filter_by(is_active=True).order_by(PlayerCharacter.experience.desc()).limit(10).all()
            else:
                return []
            
            leaderboard = []
            for i, char in enumerate(characters, 1):
                win_rate = (char.wins / (char.wins + char.losses) * 100) if (char.wins + char.losses) > 0 else 0
                leaderboard.append({
                    'rank': i,
                    'character_name': char.character_name,
                    'level': char.level,
                    'wins': char.wins,
                    'losses': char.losses,
                    'win_rate': round(win_rate, 1),
                    'experience': char.experience
                })
            
            return leaderboard
            
        except Exception as e:
            logger.error(f"Erro ao obter leaderboard: {e}")
            return []

