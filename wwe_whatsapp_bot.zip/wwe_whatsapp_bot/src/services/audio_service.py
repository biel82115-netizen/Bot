import os
import tempfile
import logging
from typing import Optional, Tuple
import yt_dlp
from pydub import AudioSegment
from pydub.exceptions import CouldntDecodeError

logger = logging.getLogger(__name__)

class AudioService:
    """Serviço para processamento e download de áudio"""
    
    def __init__(self, download_path: str = './downloads/audio', max_duration: int = 300):
        self.download_path = download_path
        self.max_duration = max_duration
        
        # Criar diretório se não existir
        os.makedirs(self.download_path, exist_ok=True)
        
        # Configurações do yt-dlp
        self.ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': os.path.join(self.download_path, '%(title)s.%(ext)s'),
            'noplaylist': True,
            'extractaudio': True,
            'audioformat': 'mp3',
            'audioquality': '192K',
            'quiet': True,
            'no_warnings': True
        }
    
    def search_and_download_audio(self, query: str, search_prefix: str = "entrance music") -> Optional[Tuple[str, str, int]]:
        """
        Buscar e baixar áudio do YouTube
        
        Returns:
            Tuple[file_path, title, duration] ou None se falhar
        """
        try:
            with yt_dlp.YoutubeDL(self.ydl_opts) as ydl:
                # Buscar no YouTube
                search_query = f"ytsearch1:{query} {search_prefix}"
                logger.info(f"Buscando: {search_query}")
                
                info = ydl.extract_info(search_query, download=False)
                
                if not info or 'entries' not in info or len(info['entries']) == 0:
                    logger.warning(f"Nenhum resultado encontrado para: {query}")
                    return None
                
                video_info = info['entries'][0]
                title = video_info.get('title', 'Música')
                duration = video_info.get('duration', 0)
                
                # Verificar duração
                if duration > self.max_duration:
                    logger.warning(f"Música muito longa: {duration}s > {self.max_duration}s")
                    return None
                
                # Download do áudio
                logger.info(f"Baixando: {title}")
                ydl.download([video_info['webpage_url']])
                
                # Encontrar arquivo baixado
                downloaded_file = self._find_downloaded_file(title)
                
                if downloaded_file and os.path.exists(downloaded_file):
                    logger.info(f"Download concluído: {downloaded_file}")
                    return downloaded_file, title, duration
                else:
                    logger.error("Arquivo baixado não encontrado")
                    return None
                    
        except Exception as e:
            logger.error(f"Erro ao baixar áudio: {e}")
            return None
    
    def _find_downloaded_file(self, title: str) -> Optional[str]:
        """Encontrar arquivo baixado baseado no título"""
        try:
            # Limpar título para busca
            clean_title = title.replace('/', '_').replace('\\', '_')
            
            # Procurar arquivo no diretório
            for file in os.listdir(self.download_path):
                if any(part in file for part in clean_title.split()[:3]):  # Usar primeiras 3 palavras
                    return os.path.join(self.download_path, file)
            
            # Se não encontrou, pegar o arquivo mais recente
            files = [os.path.join(self.download_path, f) for f in os.listdir(self.download_path)]
            if files:
                latest_file = max(files, key=os.path.getctime)
                return latest_file
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao encontrar arquivo: {e}")
            return None
    
    def convert_for_whatsapp(self, input_file: str) -> Optional[str]:
        """
        Converter áudio para formato compatível com WhatsApp
        
        Returns:
            Caminho do arquivo convertido ou None se falhar
        """
        try:
            logger.info(f"Convertendo áudio: {input_file}")
            
            # Carregar áudio
            audio = AudioSegment.from_file(input_file)
            
            # Limitar duração se necessário
            if len(audio) > self.max_duration * 1000:
                logger.info(f"Cortando áudio para {self.max_duration}s")
                audio = audio[:self.max_duration * 1000]
            
            # Ajustar qualidade para WhatsApp
            # WhatsApp suporta OGG/Opus para mensagens de voz
            audio = audio.set_frame_rate(16000)  # 16kHz é suficiente para voz
            audio = audio.set_channels(1)  # Mono
            
            # Gerar nome do arquivo de saída
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            output_file = os.path.join(self.download_path, f"{base_name}_whatsapp.ogg")
            
            # Exportar em formato OGG/Opus
            audio.export(
                output_file,
                format="ogg",
                codec="libopus",
                parameters=["-b:a", "64k"]  # 64kbps é suficiente
            )
            
            logger.info(f"Áudio convertido: {output_file}")
            return output_file
            
        except CouldntDecodeError as e:
            logger.error(f"Erro ao decodificar áudio: {e}")
            return None
        except Exception as e:
            logger.error(f"Erro ao converter áudio: {e}")
            return None
    
    def process_audio_for_whatsapp(self, query: str) -> Optional[Tuple[str, str]]:
        """
        Processo completo: buscar, baixar e converter áudio para WhatsApp
        
        Returns:
            Tuple[file_path, title] ou None se falhar
        """
        try:
            # Buscar e baixar
            result = self.search_and_download_audio(query)
            if not result:
                return None
            
            downloaded_file, title, duration = result
            
            # Converter para WhatsApp
            converted_file = self.convert_for_whatsapp(downloaded_file)
            if not converted_file:
                return None
            
            # Limpar arquivo original se diferente do convertido
            if downloaded_file != converted_file:
                try:
                    os.remove(downloaded_file)
                except:
                    pass  # Ignorar erro ao remover arquivo original
            
            return converted_file, title
            
        except Exception as e:
            logger.error(f"Erro no processamento de áudio: {e}")
            return None
    
    def cleanup_old_files(self, max_age_hours: int = 24):
        """Limpar arquivos antigos do diretório de download"""
        try:
            import time
            current_time = time.time()
            max_age_seconds = max_age_hours * 3600
            
            for filename in os.listdir(self.download_path):
                file_path = os.path.join(self.download_path, filename)
                if os.path.isfile(file_path):
                    file_age = current_time - os.path.getctime(file_path)
                    if file_age > max_age_seconds:
                        os.remove(file_path)
                        logger.info(f"Arquivo antigo removido: {filename}")
                        
        except Exception as e:
            logger.error(f"Erro ao limpar arquivos antigos: {e}")
    
    def get_audio_info(self, file_path: str) -> Optional[dict]:
        """Obter informações do arquivo de áudio"""
        try:
            audio = AudioSegment.from_file(file_path)
            return {
                'duration': len(audio) / 1000,  # em segundos
                'channels': audio.channels,
                'frame_rate': audio.frame_rate,
                'sample_width': audio.sample_width,
                'file_size': os.path.getsize(file_path)
            }
        except Exception as e:
            logger.error(f"Erro ao obter info do áudio: {e}")
            return None
    
    def create_audio_preview(self, file_path: str, preview_duration: int = 30) -> Optional[str]:
        """Criar preview de áudio (primeiros X segundos)"""
        try:
            audio = AudioSegment.from_file(file_path)
            
            # Criar preview
            preview = audio[:preview_duration * 1000]
            
            # Salvar preview
            base_name = os.path.splitext(os.path.basename(file_path))[0]
            preview_file = os.path.join(self.download_path, f"{base_name}_preview.ogg")
            
            preview.export(preview_file, format="ogg", codec="libopus")
            
            return preview_file
            
        except Exception as e:
            logger.error(f"Erro ao criar preview: {e}")
            return None

