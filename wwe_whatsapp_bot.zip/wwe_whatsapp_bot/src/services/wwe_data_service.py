import requests
from bs4 import BeautifulSoup
import json
import logging
from typing import Dict, List, Optional
from src.models.wwe_character import WWECharacter, db

logger = logging.getLogger(__name__)

class WWEDataService:
    """Serviço para coleta e gerenciamento de dados WWE"""
    
    def __init__(self):
        self.base_urls = {
            'wwe_official': 'https://www.wwe.com',
            'wikipedia': 'https://en.wikipedia.org'
        }
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get_popular_wwe_characters(self) -> List[Dict]:
        """Obter lista de personagens WWE populares"""
        try:
            # Lista básica de personagens WWE populares (pode ser expandida)
            popular_characters = [
                {
                    'name': 'John Cena',
                    'real_name': 'John Felix Anthony Cena Jr.',
                    'nickname': 'The Cenation Leader',
                    'brand': 'RAW',
                    'height': '6 ft 1 in',
                    'weight': '251 lbs',
                    'hometown': 'West Newbury, Massachusetts',
                    'signature_moves': ['Five Knuckle Shuffle', 'Flying Shoulder Block'],
                    'finisher_moves': ['Attitude Adjustment', 'STF/STFU'],
                    'entrance_music': 'The Time Is Now',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=4feIwig2AtA'
                },
                {
                    'name': 'Roman Reigns',
                    'real_name': 'Leati Joseph Anoa\'i',
                    'nickname': 'The Tribal Chief',
                    'brand': 'SmackDown',
                    'height': '6 ft 3 in',
                    'weight': '265 lbs',
                    'hometown': 'Pensacola, Florida',
                    'signature_moves': ['Superman Punch', 'Samoan Drop'],
                    'finisher_moves': ['Spear', 'Guillotine Choke'],
                    'entrance_music': 'Head of the Table',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=TmPKjrh7kN0'
                },
                {
                    'name': 'The Undertaker',
                    'real_name': 'Mark William Calaway',
                    'nickname': 'The Deadman',
                    'brand': 'Legend',
                    'height': '6 ft 10 in',
                    'weight': '309 lbs',
                    'hometown': 'Death Valley',
                    'signature_moves': ['Big Boot', 'Snake Eyes'],
                    'finisher_moves': ['Tombstone Piledriver', 'Last Ride', 'Hell\'s Gate'],
                    'entrance_music': 'Rest in Peace',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=bzti2eWNOQs'
                },
                {
                    'name': 'Stone Cold Steve Austin',
                    'real_name': 'Steven James Anderson',
                    'nickname': 'The Texas Rattlesnake',
                    'brand': 'Legend',
                    'height': '6 ft 2 in',
                    'weight': '252 lbs',
                    'hometown': 'Victoria, Texas',
                    'signature_moves': ['Lou Thesz Press', 'Slingshot Suplex'],
                    'finisher_moves': ['Stone Cold Stunner'],
                    'entrance_music': 'I Won\'t Do What You Tell Me',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=0jgrCKhxE1s'
                },
                {
                    'name': 'The Rock',
                    'real_name': 'Dwayne Johnson',
                    'nickname': 'The People\'s Champion',
                    'brand': 'Legend',
                    'height': '6 ft 5 in',
                    'weight': '260 lbs',
                    'hometown': 'Miami, Florida',
                    'signature_moves': ['Samoan Drop', 'Belly-to-Belly Suplex'],
                    'finisher_moves': ['Rock Bottom', 'People\'s Elbow'],
                    'entrance_music': 'Electrifying',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=bE0UB1eEGB4'
                },
                {
                    'name': 'CM Punk',
                    'real_name': 'Phillip Jack Brooks',
                    'nickname': 'The Best in the World',
                    'brand': 'RAW',
                    'height': '6 ft 2 in',
                    'weight': '218 lbs',
                    'hometown': 'Chicago, Illinois',
                    'signature_moves': ['Scoop Slam', 'Springboard Clothesline'],
                    'finisher_moves': ['GTS (Go To Sleep)', 'Anaconda Vise'],
                    'entrance_music': 'Cult of Personality',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=7xxgRUyzgs0'
                },
                {
                    'name': 'Brock Lesnar',
                    'real_name': 'Brock Edward Lesnar',
                    'nickname': 'The Beast Incarnate',
                    'brand': 'SmackDown',
                    'height': '6 ft 3 in',
                    'weight': '286 lbs',
                    'hometown': 'Webster, South Dakota',
                    'signature_moves': ['German Suplex', 'Belly-to-Belly Suplex'],
                    'finisher_moves': ['F5', 'Kimura Lock'],
                    'entrance_music': 'Next Big Thing',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=FDbWm4RPp10'
                },
                {
                    'name': 'Seth Rollins',
                    'real_name': 'Colby Daniel Lopez',
                    'nickname': 'The Visionary',
                    'brand': 'RAW',
                    'height': '6 ft 1 in',
                    'weight': '217 lbs',
                    'hometown': 'Davenport, Iowa',
                    'signature_moves': ['Superkick', 'Knee Trembler'],
                    'finisher_moves': ['Stomp', 'Pedigree'],
                    'entrance_music': 'The Second Coming',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=BsUWkuJZLyQ'
                },
                {
                    'name': 'Triple H',
                    'real_name': 'Paul Michael Levesque',
                    'nickname': 'The Game',
                    'brand': 'Legend',
                    'height': '6 ft 4 in',
                    'weight': '255 lbs',
                    'hometown': 'Greenwich, Connecticut',
                    'signature_moves': ['High Knee', 'Spinebuster'],
                    'finisher_moves': ['Pedigree', 'Sledgehammer'],
                    'entrance_music': 'The Game',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=F_JF8oSxXtM'
                },
                {
                    'name': 'Shawn Michaels',
                    'real_name': 'Michael Shawn Hickenbottom',
                    'nickname': 'Mr. WrestleMania',
                    'brand': 'Legend',
                    'height': '6 ft 1 in',
                    'weight': '225 lbs',
                    'hometown': 'San Antonio, Texas',
                    'signature_moves': ['Flying Forearm', 'Inverted Atomic Drop'],
                    'finisher_moves': ['Sweet Chin Music', 'Figure Four Leglock'],
                    'entrance_music': 'Sexy Boy',
                    'entrance_music_url': 'https://www.youtube.com/watch?v=kgW2G5QoHFY'
                }
            ]
            
            return popular_characters
            
        except Exception as e:
            logger.error(f"Erro ao obter personagens WWE: {e}")
            return []
    
    def populate_database_with_characters(self):
        """Popular banco de dados com personagens WWE"""
        try:
            characters_data = self.get_popular_wwe_characters()
            
            for char_data in characters_data:
                # Verificar se personagem já existe
                existing = WWECharacter.query.filter_by(name=char_data['name']).first()
                
                if not existing:
                    # Calcular stats baseados no personagem
                    stats = self.calculate_character_stats(char_data)
                    
                    character = WWECharacter(
                        name=char_data['name'],
                        real_name=char_data['real_name'],
                        nickname=char_data['nickname'],
                        brand=char_data['brand'],
                        height=char_data['height'],
                        weight=char_data['weight'],
                        hometown=char_data['hometown'],
                        signature_moves=json.dumps(char_data['signature_moves']),
                        finisher_moves=json.dumps(char_data['finisher_moves']),
                        entrance_music=char_data['entrance_music'],
                        entrance_music_url=char_data['entrance_music_url'],
                        strength=stats['strength'],
                        speed=stats['speed'],
                        charisma=stats['charisma'],
                        technique=stats['technique'],
                        stamina=stats['stamina']
                    )
                    
                    db.session.add(character)
            
            db.session.commit()
            logger.info(f"Banco de dados populado com {len(characters_data)} personagens")
            
        except Exception as e:
            logger.error(f"Erro ao popular banco de dados: {e}")
            db.session.rollback()
    
    def calculate_character_stats(self, char_data: Dict) -> Dict[str, int]:
        """Calcular estatísticas do personagem baseado em dados"""
        # Sistema básico de cálculo de stats
        # Pode ser melhorado com dados mais específicos
        
        stats = {
            'strength': 50,
            'speed': 50,
            'charisma': 50,
            'technique': 50,
            'stamina': 50
        }
        
        name = char_data['name'].lower()
        
        # Ajustes baseados no personagem (sistema básico)
        if 'brock lesnar' in name:
            stats.update({'strength': 95, 'speed': 60, 'stamina': 90, 'technique': 75, 'charisma': 70})
        elif 'john cena' in name:
            stats.update({'strength': 85, 'speed': 70, 'stamina': 90, 'technique': 80, 'charisma': 95})
        elif 'undertaker' in name:
            stats.update({'strength': 90, 'speed': 65, 'stamina': 85, 'technique': 90, 'charisma': 95})
        elif 'stone cold' in name:
            stats.update({'strength': 85, 'speed': 75, 'stamina': 80, 'technique': 85, 'charisma': 95})
        elif 'the rock' in name:
            stats.update({'strength': 85, 'speed': 70, 'stamina': 85, 'technique': 80, 'charisma': 100})
        elif 'cm punk' in name:
            stats.update({'strength': 70, 'speed': 85, 'stamina': 80, 'technique': 90, 'charisma': 85})
        elif 'roman reigns' in name:
            stats.update({'strength': 90, 'speed': 75, 'stamina': 85, 'technique': 80, 'charisma': 80})
        elif 'seth rollins' in name:
            stats.update({'strength': 75, 'speed': 90, 'stamina': 85, 'technique': 95, 'charisma': 85})
        elif 'triple h' in name:
            stats.update({'strength': 85, 'speed': 70, 'stamina': 85, 'technique': 90, 'charisma': 90})
        elif 'shawn michaels' in name:
            stats.update({'strength': 75, 'speed': 95, 'stamina': 80, 'technique': 100, 'charisma': 90})
        
        return stats
    
    def get_entrance_music_suggestions(self, query: str) -> List[str]:
        """Obter sugestões de música de entrada baseadas na consulta"""
        try:
            # Lista básica de músicas de entrada populares
            entrance_music = [
                "John Cena - The Time Is Now",
                "The Undertaker - Rest in Peace",
                "Stone Cold Steve Austin - I Won't Do What You Tell Me",
                "The Rock - Electrifying",
                "Triple H - The Game",
                "Shawn Michaels - Sexy Boy",
                "CM Punk - Cult of Personality",
                "Roman Reigns - Head of the Table",
                "Seth Rollins - The Second Coming",
                "Brock Lesnar - Next Big Thing",
                "Daniel Bryan - Flight of the Valkyries",
                "AJ Styles - Phenomenal",
                "Edge - Metalingus",
                "Randy Orton - Voices",
                "Batista - I Walk Alone"
            ]
            
            # Filtrar baseado na consulta
            if query:
                filtered = [music for music in entrance_music 
                           if query.lower() in music.lower()]
                return filtered[:5]  # Retornar top 5
            
            return entrance_music[:10]  # Retornar top 10
            
        except Exception as e:
            logger.error(f"Erro ao obter sugestões de música: {e}")
            return []
    
    def get_character_by_name(self, name: str) -> Optional[WWECharacter]:
        """Buscar personagem por nome"""
        try:
            return WWECharacter.query.filter(
                WWECharacter.name.ilike(f'%{name}%')
            ).first()
        except Exception as e:
            logger.error(f"Erro ao buscar personagem: {e}")
            return None
    
    def get_random_character(self) -> Optional[WWECharacter]:
        """Obter personagem aleatório"""
        try:
            import random
            characters = WWECharacter.query.filter_by(is_active=True).all()
            if characters:
                return random.choice(characters)
            return None
        except Exception as e:
            logger.error(f"Erro ao obter personagem aleatório: {e}")
            return None
    
    def get_match_types(self) -> List[Dict]:
        """Obter tipos de luta disponíveis"""
        return [
            {
                'type': 'singles',
                'name': 'Singles Match',
                'description': 'Luta individual 1 vs 1',
                'participants': 2
            },
            {
                'type': 'tag_team',
                'name': 'Tag Team Match',
                'description': 'Luta em duplas 2 vs 2',
                'participants': 4
            },
            {
                'type': 'triple_threat',
                'name': 'Triple Threat Match',
                'description': 'Luta de três lutadores',
                'participants': 3
            },
            {
                'type': 'fatal_4_way',
                'name': 'Fatal 4-Way Match',
                'description': 'Luta de quatro lutadores',
                'participants': 4
            },
            {
                'type': 'royal_rumble',
                'name': 'Royal Rumble',
                'description': 'Luta eliminatória com múltiplos participantes',
                'participants': 30
            },
            {
                'type': 'ladder',
                'name': 'Ladder Match',
                'description': 'Luta com escadas para alcançar objeto suspenso',
                'participants': 2
            },
            {
                'type': 'cage',
                'name': 'Steel Cage Match',
                'description': 'Luta dentro de uma gaiola de aço',
                'participants': 2
            },
            {
                'type': 'hell_in_a_cell',
                'name': 'Hell in a Cell',
                'description': 'Luta dentro da estrutura Hell in a Cell',
                'participants': 2
            }
        ]

