import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, asdict
from src.models.user import db

logger = logging.getLogger(__name__)

@dataclass
class UserWarning:
    """Estrutura para avisos de usuário"""
    reason: str
    timestamp: datetime
    admin_id: str
    severity: str = "medium"  # low, medium, high, critical

@dataclass
class BanRecord:
    """Estrutura para registros de banimento"""
    user_id: str
    admin_id: str
    reason: str
    timestamp: datetime
    duration: Optional[int] = None  # em minutos, None = permanente
    is_active: bool = True

@dataclass
class MuteRecord:
    """Estrutura para registros de mute"""
    user_id: str
    admin_id: str
    reason: str
    timestamp: datetime
    duration: Optional[int] = None  # em minutos, None = permanente
    is_active: bool = True

class AdminService:
    """Serviço avançado de administração para o bot"""
    
    def __init__(self, admin_numbers: List[str]):
        self.admin_numbers = set(admin_numbers)
        self.banned_users: Dict[str, BanRecord] = {}
        self.muted_users: Dict[str, MuteRecord] = {}
        self.user_warnings: Dict[str, List[UserWarning]] = {}
        
        # Configurações de moderação automática
        self.auto_moderation_config = {
            'max_warnings': 3,
            'warning_reset_hours': 24,
            'spam_threshold': 5,  # mensagens por minuto
            'spam_window_minutes': 1,
            'forbidden_words': [
                'spam', 'hack', 'cheat', 'bot', 'scam', 'fake',
                'virus', 'malware', 'phishing'
            ],
            'auto_ban_on_max_warnings': True,
            'auto_mute_spam': True
        }
        
        # Tracking de atividade de usuários
        self.user_activity: Dict[str, List[datetime]] = {}
        
        # Níveis de permissão
        self.permission_levels = {
            'super_admin': ['ban', 'unban', 'mute', 'unmute', 'warn', 'kick', 'config'],
            'admin': ['mute', 'unmute', 'warn', 'kick'],
            'moderator': ['warn', 'mute']
        }
        
        # Atribuir níveis aos admins (pode ser configurado)
        self.admin_levels: Dict[str, str] = {}
        for admin in self.admin_numbers:
            self.admin_levels[admin] = 'super_admin'  # Por padrão, todos são super_admin
    
    def is_admin(self, user_id: str) -> bool:
        """Verificar se usuário é administrador"""
        return user_id in self.admin_numbers
    
    def has_permission(self, user_id: str, action: str) -> bool:
        """Verificar se usuário tem permissão para ação"""
        if not self.is_admin(user_id):
            return False
        
        user_level = self.admin_levels.get(user_id, 'moderator')
        allowed_actions = self.permission_levels.get(user_level, [])
        
        return action in allowed_actions
    
    def add_warning(self, user_id: str, reason: str, admin_id: str, severity: str = "medium") -> Dict:
        """Adicionar aviso a usuário"""
        try:
            if user_id not in self.user_warnings:
                self.user_warnings[user_id] = []
            
            warning = UserWarning(
                reason=reason,
                timestamp=datetime.now(),
                admin_id=admin_id,
                severity=severity
            )
            
            self.user_warnings[user_id].append(warning)
            
            # Limpar avisos antigos
            self._cleanup_old_warnings(user_id)
            
            current_warnings = len(self.user_warnings[user_id])
            
            result = {
                'success': True,
                'warning_count': current_warnings,
                'max_warnings': self.auto_moderation_config['max_warnings'],
                'auto_action': None
            }
            
            # Verificar se deve aplicar ação automática
            if (current_warnings >= self.auto_moderation_config['max_warnings'] and 
                self.auto_moderation_config['auto_ban_on_max_warnings']):
                
                ban_result = self.ban_user(user_id, admin_id, "Máximo de avisos atingido", duration=1440)  # 24h
                result['auto_action'] = 'ban'
                result['ban_result'] = ban_result
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao adicionar aviso: {e}")
            return {'success': False, 'error': str(e)}
    
    def ban_user(self, user_id: str, admin_id: str, reason: str, duration: Optional[int] = None) -> Dict:
        """Banir usuário"""
        try:
            ban_record = BanRecord(
                user_id=user_id,
                admin_id=admin_id,
                reason=reason,
                timestamp=datetime.now(),
                duration=duration,
                is_active=True
            )
            
            self.banned_users[user_id] = ban_record
            
            # Remover de muted se estava mutado
            if user_id in self.muted_users:
                del self.muted_users[user_id]
            
            return {
                'success': True,
                'ban_type': 'temporary' if duration else 'permanent',
                'duration_minutes': duration,
                'expires_at': (datetime.now() + timedelta(minutes=duration)).isoformat() if duration else None
            }
            
        except Exception as e:
            logger.error(f"Erro ao banir usuário: {e}")
            return {'success': False, 'error': str(e)}
    
    def unban_user(self, user_id: str, admin_id: str) -> Dict:
        """Desbanir usuário"""
        try:
            if user_id not in self.banned_users:
                return {'success': False, 'error': 'Usuário não está banido'}
            
            # Marcar ban como inativo
            self.banned_users[user_id].is_active = False
            del self.banned_users[user_id]
            
            return {'success': True}
            
        except Exception as e:
            logger.error(f"Erro ao desbanir usuário: {e}")
            return {'success': False, 'error': str(e)}
    
    def mute_user(self, user_id: str, admin_id: str, reason: str, duration: Optional[int] = None) -> Dict:
        """Mutar usuário"""
        try:
            mute_record = MuteRecord(
                user_id=user_id,
                admin_id=admin_id,
                reason=reason,
                timestamp=datetime.now(),
                duration=duration,
                is_active=True
            )
            
            self.muted_users[user_id] = mute_record
            
            return {
                'success': True,
                'mute_type': 'temporary' if duration else 'permanent',
                'duration_minutes': duration,
                'expires_at': (datetime.now() + timedelta(minutes=duration)).isoformat() if duration else None
            }
            
        except Exception as e:
            logger.error(f"Erro ao mutar usuário: {e}")
            return {'success': False, 'error': str(e)}
    
    def unmute_user(self, user_id: str, admin_id: str) -> Dict:
        """Desmutar usuário"""
        try:
            if user_id not in self.muted_users:
                return {'success': False, 'error': 'Usuário não está mutado'}
            
            # Marcar mute como inativo
            self.muted_users[user_id].is_active = False
            del self.muted_users[user_id]
            
            return {'success': True}
            
        except Exception as e:
            logger.error(f"Erro ao desmutar usuário: {e}")
            return {'success': False, 'error': str(e)}
    
    def is_user_banned(self, user_id: str) -> bool:
        """Verificar se usuário está banido"""
        if user_id not in self.banned_users:
            return False
        
        ban_record = self.banned_users[user_id]
        
        # Verificar se ban temporário expirou
        if ban_record.duration:
            expires_at = ban_record.timestamp + timedelta(minutes=ban_record.duration)
            if datetime.now() > expires_at:
                # Ban expirou, remover
                del self.banned_users[user_id]
                return False
        
        return ban_record.is_active
    
    def is_user_muted(self, user_id: str) -> bool:
        """Verificar se usuário está mutado"""
        if user_id not in self.muted_users:
            return False
        
        mute_record = self.muted_users[user_id]
        
        # Verificar se mute temporário expirou
        if mute_record.duration:
            expires_at = mute_record.timestamp + timedelta(minutes=mute_record.duration)
            if datetime.now() > expires_at:
                # Mute expirou, remover
                del self.muted_users[user_id]
                return False
        
        return mute_record.is_active
    
    def check_auto_moderation(self, user_id: str, message_text: str) -> Dict:
        """Verificar regras de moderação automática"""
        try:
            violations = []
            actions_taken = []
            
            # Verificar palavras proibidas
            text_lower = message_text.lower()
            for word in self.auto_moderation_config['forbidden_words']:
                if word in text_lower:
                    violations.append(f"Palavra proibida: {word}")
            
            # Verificar spam
            if self._is_spam(user_id):
                violations.append("Spam detectado")
                if self.auto_moderation_config['auto_mute_spam']:
                    mute_result = self.mute_user(user_id, "system", "Auto-mute por spam", duration=60)
                    if mute_result['success']:
                        actions_taken.append("Auto-mute aplicado")
            
            # Verificar mensagem muito longa
            if len(message_text) > 1000:
                violations.append("Mensagem muito longa")
            
            # Aplicar avisos se houver violações
            if violations and user_id not in self.banned_users:
                for violation in violations:
                    warning_result = self.add_warning(user_id, violation, "system", "medium")
                    if warning_result.get('auto_action') == 'ban':
                        actions_taken.append("Auto-ban aplicado")
            
            return {
                'violations': violations,
                'actions_taken': actions_taken,
                'should_block_message': bool(violations)
            }
            
        except Exception as e:
            logger.error(f"Erro na moderação automática: {e}")
            return {'violations': [], 'actions_taken': [], 'should_block_message': False}
    
    def _is_spam(self, user_id: str) -> bool:
        """Verificar se usuário está fazendo spam"""
        try:
            now = datetime.now()
            
            # Inicializar tracking se necessário
            if user_id not in self.user_activity:
                self.user_activity[user_id] = []
            
            # Adicionar timestamp atual
            self.user_activity[user_id].append(now)
            
            # Limpar timestamps antigos
            window_start = now - timedelta(minutes=self.auto_moderation_config['spam_window_minutes'])
            self.user_activity[user_id] = [
                ts for ts in self.user_activity[user_id] 
                if ts > window_start
            ]
            
            # Verificar se excedeu threshold
            return len(self.user_activity[user_id]) > self.auto_moderation_config['spam_threshold']
            
        except Exception as e:
            logger.error(f"Erro ao verificar spam: {e}")
            return False
    
    def _cleanup_old_warnings(self, user_id: str):
        """Limpar avisos antigos"""
        try:
            if user_id not in self.user_warnings:
                return
            
            cutoff_time = datetime.now() - timedelta(hours=self.auto_moderation_config['warning_reset_hours'])
            
            self.user_warnings[user_id] = [
                warning for warning in self.user_warnings[user_id]
                if warning.timestamp > cutoff_time
            ]
            
            # Remover entrada se não há avisos
            if not self.user_warnings[user_id]:
                del self.user_warnings[user_id]
                
        except Exception as e:
            logger.error(f"Erro ao limpar avisos antigos: {e}")
    
    def get_user_status(self, user_id: str) -> Dict:
        """Obter status completo do usuário"""
        try:
            warnings = self.user_warnings.get(user_id, [])
            banned = self.is_user_banned(user_id)
            muted = self.is_user_muted(user_id)
            
            status = {
                'user_id': user_id,
                'is_admin': self.is_admin(user_id),
                'admin_level': self.admin_levels.get(user_id),
                'is_banned': banned,
                'is_muted': muted,
                'warning_count': len(warnings),
                'warnings': [asdict(w) for w in warnings[-5:]],  # Últimos 5 avisos
            }
            
            if banned and user_id in self.banned_users:
                ban_record = self.banned_users[user_id]
                status['ban_info'] = {
                    'reason': ban_record.reason,
                    'admin_id': ban_record.admin_id,
                    'timestamp': ban_record.timestamp.isoformat(),
                    'duration': ban_record.duration,
                    'expires_at': (ban_record.timestamp + timedelta(minutes=ban_record.duration)).isoformat() if ban_record.duration else None
                }
            
            if muted and user_id in self.muted_users:
                mute_record = self.muted_users[user_id]
                status['mute_info'] = {
                    'reason': mute_record.reason,
                    'admin_id': mute_record.admin_id,
                    'timestamp': mute_record.timestamp.isoformat(),
                    'duration': mute_record.duration,
                    'expires_at': (mute_record.timestamp + timedelta(minutes=mute_record.duration)).isoformat() if mute_record.duration else None
                }
            
            return status
            
        except Exception as e:
            logger.error(f"Erro ao obter status do usuário: {e}")
            return {'error': str(e)}
    
    def get_admin_stats(self) -> Dict:
        """Obter estatísticas administrativas"""
        try:
            return {
                'total_admins': len(self.admin_numbers),
                'banned_users': len(self.banned_users),
                'muted_users': len(self.muted_users),
                'users_with_warnings': len(self.user_warnings),
                'total_warnings': sum(len(warnings) for warnings in self.user_warnings.values()),
                'auto_moderation_config': self.auto_moderation_config,
                'admin_levels': dict(self.admin_levels)
            }
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            return {'error': str(e)}
    
    def update_config(self, admin_id: str, config_updates: Dict) -> Dict:
        """Atualizar configurações de moderação"""
        try:
            if not self.has_permission(admin_id, 'config'):
                return {'success': False, 'error': 'Sem permissão para alterar configurações'}
            
            # Validar e aplicar atualizações
            valid_keys = self.auto_moderation_config.keys()
            
            for key, value in config_updates.items():
                if key in valid_keys:
                    self.auto_moderation_config[key] = value
            
            return {
                'success': True,
                'updated_config': self.auto_moderation_config
            }
            
        except Exception as e:
            logger.error(f"Erro ao atualizar configurações: {e}")
            return {'success': False, 'error': str(e)}
    
    def export_logs(self, admin_id: str) -> Dict:
        """Exportar logs de moderação"""
        try:
            if not self.has_permission(admin_id, 'config'):
                return {'success': False, 'error': 'Sem permissão para exportar logs'}
            
            logs = {
                'export_timestamp': datetime.now().isoformat(),
                'banned_users': {k: asdict(v) for k, v in self.banned_users.items()},
                'muted_users': {k: asdict(v) for k, v in self.muted_users.items()},
                'user_warnings': {
                    k: [asdict(w) for w in v] 
                    for k, v in self.user_warnings.items()
                },
                'admin_stats': self.get_admin_stats()
            }
            
            return {'success': True, 'logs': logs}
            
        except Exception as e:
            logger.error(f"Erro ao exportar logs: {e}")
            return {'success': False, 'error': str(e)}

