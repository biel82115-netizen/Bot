# 🚂 Deploy no Railway - WWE RPG WhatsApp Bot

## 🎯 Por que Railway?

- ✅ **Gratuito** ($5 créditos mensais)
- ✅ **Deploy em 5 minutos**
- ✅ **Bot online 24/7**
- ✅ **Zero configuração de servidor**
- ✅ **Logs em tempo real**
- ✅ **SSL automático**

---

## 🚀 Passo a Passo (5 minutos)

### 1️⃣ Preparar Arquivos

1. **Extrair o projeto**:
```bash
tar -xzf wwe_whatsapp_bot_completo.tar.gz
```

2. **Criar arquivo Procfile**:
```bash
cd wwe_whatsapp_bot
echo "web: python src/main.py" > Procfile
```

3. **Criar runtime.txt**:
```bash
echo "python-3.11.0" > runtime.txt
```

### 2️⃣ Configurar Railway

1. **Acesse**: [railway.app](https://railway.app)
2. **Clique**: "Start a New Project"
3. **Selecione**: "Deploy from GitHub repo"
4. **Conecte** sua conta GitHub
5. **Crie** um novo repositório ou use existente

### 3️⃣ Upload dos Arquivos

**Opção A - Via GitHub**:
1. Crie repositório no GitHub
2. Faça upload dos arquivos
3. Conecte no Railway

**Opção B - Via Railway CLI**:
```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy
railway deploy
```

### 4️⃣ Configurar Variáveis de Ambiente

No painel do Railway:

1. **Vá para**: "Variables"
2. **Adicione**:

```env
WHATSAPP_TOKEN=seu_token_aqui
VERIFY_TOKEN=meutoken123
PHONE_NUMBER_ID=seu_phone_id
WHATSAPP_BUSINESS_ACCOUNT_ID=seu_business_id
ADMIN_NUMBERS=+5511999999999
PORT=5000
```

### 5️⃣ Deploy Final

1. **Clique**: "Deploy"
2. **Aguarde**: 2-3 minutos
3. **Copie**: URL gerada (ex: `https://seu-bot.railway.app`)

---

## 🔗 Configurar Webhook WhatsApp

1. **Acesse**: [developers.facebook.com](https://developers.facebook.com)
2. **Vá para**: Seu app WhatsApp
3. **Configure webhook**:
   - **URL**: `https://seu-bot.railway.app/api/webhook`
   - **Token**: `meutoken123`
   - **Eventos**: `messages`

---

## 🧪 Testar o Bot

1. **Envie mensagem** para o número do bot
2. **Teste comandos**:
   - `!help`
   - `!play john cena`
   - `!character Stone Cold`

---

## 📊 Monitorar o Bot

### Logs em Tempo Real
1. **Railway Dashboard** → "Deployments"
2. **Clique** no deployment ativo
3. **Veja logs** em tempo real

### Métricas
- **CPU/RAM**: Monitoramento automático
- **Requests**: Contador de requisições
- **Uptime**: Disponibilidade 24/7

---

## 💰 Custos Railway

### Plano Gratuito
- **$5 créditos/mês**
- **500 horas** de execução
- **1GB RAM**
- **1GB storage**

### Para o Bot WWE:
- **Consumo estimado**: $2-3/mês
- **Sobra créditos** para outros projetos
- **Upgrade** só se necessário

---

## 🔧 Configurações Avançadas

### Arquivo railway.toml
```toml
[build]
builder = "NIXPACKS"

[deploy]
healthcheckPath = "/api/webhook/status"
healthcheckTimeout = 300
restartPolicyType = "ON_FAILURE"
```

### Variáveis de Produção
```env
DEBUG=False
LOG_LEVEL=INFO
DATABASE_URL=postgresql://... # Se quiser PostgreSQL
```

---

## 🆘 Solução de Problemas

### Bot não inicia
1. **Verificar logs** no Railway
2. **Confirmar** variáveis de ambiente
3. **Testar** localmente primeiro

### Webhook não funciona
1. **URL correta**: `https://seu-bot.railway.app/api/webhook`
2. **Token correto**: Mesmo do .env
3. **Testar** endpoint: `GET /api/webhook/status`

### Consumo alto
1. **Verificar logs** para loops
2. **Otimizar** cache de áudio
3. **Limitar** downloads simultâneos

---

## 🎉 Vantagens do Railway

### vs Heroku
- ✅ **Mais créditos gratuitos**
- ✅ **Deploy mais rápido**
- ✅ **Interface mais moderna**

### vs VPS
- ✅ **Zero configuração**
- ✅ **SSL automático**
- ✅ **Backup automático**
- ✅ **Escalabilidade**

### vs Termux
- ✅ **Estabilidade 24/7**
- ✅ **Não consome bateria**
- ✅ **Logs profissionais**
- ✅ **Monitoramento**

---

## 🚀 Próximos Passos

1. **Deploy** no Railway ✅
2. **Configurar** webhook ✅
3. **Testar** comandos ✅
4. **Adicionar** ao grupo WWE ✅
5. **Configurar** administradores ✅
6. **Aproveitar** o bot! 🎉

---

## 📞 Suporte Railway

- **Docs**: [docs.railway.app](https://docs.railway.app)
- **Discord**: Comunidade ativa
- **Status**: [status.railway.app](https://status.railway.app)

---

**🎯 Com Railway, seu bot WWE ficará online 24/7 sem você se preocupar com nada!**

*Desenvolvido por Manus AI* 🚀

